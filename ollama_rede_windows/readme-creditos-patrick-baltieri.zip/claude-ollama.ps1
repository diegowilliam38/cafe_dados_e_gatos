param(
    [string]$OllamaHost = ""
)

$ErrorActionPreference = "Stop"
trap {
    Write-Host ""
    Write-Host "ERRO FATAL no script:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Linha: $($_.InvocationInfo.ScriptLineNumber) - $($_.InvocationInfo.Line.Trim())" -ForegroundColor DarkRed
    Write-Host ""
    Read-Host "Pressione ENTER para fechar"
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ============================================================
# HELPERS (dialogs)
# ============================================================
function Show-Error($msg) { [System.Windows.Forms.MessageBox]::Show($msg, "Erro", 'OK', 'Error') | Out-Null }
function Show-Info($msg, $title = "Info") { [System.Windows.Forms.MessageBox]::Show($msg, $title, 'OK', 'Information') | Out-Null }
function Ask-YesNo($msg, $title) {
    $r = [System.Windows.Forms.MessageBox]::Show($msg, $title, 'YesNo', 'Question')
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Ask-Input($prompt, $title, $default = "") {
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $title
    $f.Size = New-Object System.Drawing.Size(440, 180)
    $f.StartPosition = "CenterScreen"
    $f.FormBorderStyle = "FixedDialog"; $f.MaximizeBox = $false; $f.MinimizeBox = $false

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $prompt; $lbl.Location = New-Object System.Drawing.Point(15, 15)
    $lbl.Size = New-Object System.Drawing.Size(400, 40); $f.Controls.Add($lbl)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Text = $default; $tb.Location = New-Object System.Drawing.Point(15, 60)
    $tb.Size = New-Object System.Drawing.Size(395, 25)
    $tb.Font = New-Object System.Drawing.Font("Consolas", 10); $f.Controls.Add($tb)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = "OK"; $ok.Location = New-Object System.Drawing.Point(230, 100)
    $ok.Size = New-Object System.Drawing.Size(85, 30)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $f.AcceptButton = $ok; $f.Controls.Add($ok)

    $cc = New-Object System.Windows.Forms.Button
    $cc.Text = "Cancelar"; $cc.Location = New-Object System.Drawing.Point(325, 100)
    $cc.Size = New-Object System.Drawing.Size(85, 30)
    $cc.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $f.CancelButton = $cc; $f.Controls.Add($cc)

    $f.Topmost = $true
    if ($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $tb.Text }
    return $null
}

function Pick-Folder($description) {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $description; $dlg.ShowNewFolderButton = $true
    if ($dlg.PSObject.Properties.Name -contains 'UseDescriptionForTitle') {
        $dlg.UseDescriptionForTitle = $true
    }
    $dlg.SelectedPath = [Environment]::GetFolderPath("Desktop")
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.SelectedPath }
    return $null
}

# ============================================================
# CONFIG (perfis de servidor + pastas recentes)
# ============================================================
$script:ConfigPath = Join-Path $env:APPDATA "ClaudeOllamaLauncher\config.json"

function Get-LauncherConfig {
    if (-not (Test-Path $script:ConfigPath)) {
        return @{
            servers       = [ordered]@{ "casa" = "http://192.168.1.80:11434" }
            defaultServer = "casa"
            defaultModels = @{}
            recentFolders = @()
        }
    }
    $raw = Get-Content $script:ConfigPath -Raw | ConvertFrom-Json -AsHashtable
    if (-not $raw.servers) { $raw.servers = @{} }
    if (-not $raw.recentFolders) { $raw.recentFolders = @() }
    if (-not $raw.defaultModels) { $raw.defaultModels = @{} }
    if (-not $raw.defaultServer -or -not $raw.servers.ContainsKey($raw.defaultServer)) {
        $raw.defaultServer = ($raw.servers.Keys | Select-Object -First 1)
    }
    return $raw
}

function Save-LauncherConfig($cfg) {
    $dir = Split-Path $script:ConfigPath -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $cfg | ConvertTo-Json -Depth 10 | Set-Content -Path $script:ConfigPath -Encoding UTF8
}

# ============================================================
# LOG DE SESSOES (item 14)
# ============================================================
$script:LogPath = Join-Path $env:APPDATA "ClaudeOllamaLauncher\launcher.log"
function Write-LauncherLog($action, $details) {
    $dir = Split-Path $script:LogPath -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "$ts | $action | $details"
    Add-Content -Path $script:LogPath -Value $line -Encoding UTF8
}

function Add-RecentFolder($cfg, $entry) {
    $entry.lastUsed = (Get-Date -Format "o")
    $cfg.recentFolders = @($cfg.recentFolders | Where-Object { $_.path -ne $entry.path })
    $cfg.recentFolders = @($entry) + $cfg.recentFolders
    if ($cfg.recentFolders.Count -gt 10) { $cfg.recentFolders = $cfg.recentFolders[0..9] }
    Save-LauncherConfig $cfg
}

# ============================================================
# OLLAMA API
# ============================================================
function Get-OllamaModels($ollamaUrl) {
    try {
        $resp = Invoke-RestMethod -Uri "$ollamaUrl/api/tags" -Method Get -TimeoutSec 10
    } catch {
        Show-Error "Nao foi possivel conectar ao Ollama em $ollamaUrl`n`n$($_.Exception.Message)"
        return $null
    }
    if (-not $resp.models -or $resp.models.Count -eq 0) { return @() }
    return $resp.models | ForEach-Object {
        [PSCustomObject]@{
            Name       = $_.name
            SizeGB     = [math]::Round($_.size / 1GB, 2)
            Family     = $_.details.family
            Parameters = $_.details.parameter_size
            Quant      = $_.details.quantization_level
        }
    }
}

function Test-OllamaServer($ollamaUrl) {
    try {
        $null = Invoke-RestMethod -Uri "$ollamaUrl/api/tags" -Method Get -TimeoutSec 5
        return $true
    } catch { return $false }
}

# ============================================================
# DESCOBRIR SERVIDORES NA REDE (item 7)
# ============================================================
function Find-OllamaServers {
    $ifaces = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -ne "127.0.0.1" -and $_.IPAddress -notlike "169.*" } |
        ForEach-Object {
            $adapter = Get-NetAdapter -InterfaceIndex $_.InterfaceIndex -ErrorAction SilentlyContinue
            [PSCustomObject]@{
                IP      = $_.IPAddress
                Prefix  = ($_.IPAddress -replace '\.\d+$','')
                Name    = $adapter.Name
                Desc    = $adapter.InterfaceDescription
                IsVirt  = ($adapter.InterfaceDescription -match 'Hyper-V|WSL|VMware|VirtualBox|Docker|vEthernet|TAP|Loopback')
            }
        } | Sort-Object IsVirt, Name

    # dialog para escolher subrede
    $f = New-Object System.Windows.Forms.Form
    $f.Text = "Qual rede escanear?"
    $f.Size = New-Object System.Drawing.Size(660, 440)
    $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
    $f.MaximizeBox = $false; $f.MinimizeBox = $false
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Marque uma ou mais subredes (faixas padrao ja pre-selecionadas):"
    $lbl.Location = New-Object System.Drawing.Point(15, 10); $lbl.Size = New-Object System.Drawing.Size(620, 22)
    $f.Controls.Add($lbl)
    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(15, 38); $lv.Size = New-Object System.Drawing.Size(620, 270)
    $lv.View = "Details"; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.CheckBoxes = $true
    $lv.Font = New-Object System.Drawing.Font("Consolas", 9)
    $lv.Columns.Add("Subrede", 140) | Out-Null
    $lv.Columns.Add("Interface / Origem", 160) | Out-Null
    $lv.Columns.Add("Descricao", 260) | Out-Null
    $lv.Columns.Add("Tipo", 60) | Out-Null

    # faixas padrao de rede privada (home/office)
    $defaultRanges = @("192.168.0", "192.168.1", "192.168.15", "10.0.0", "10.0.1")
    $addedPrefixes = @{}

    foreach ($p in $defaultRanges) {
        $it = New-Object System.Windows.Forms.ListViewItem("$p.x")
        $it.SubItems.Add("Faixa padrao") | Out-Null
        $it.SubItems.Add("Rede privada comum (home/office)") | Out-Null
        $it.SubItems.Add("padrao") | Out-Null
        $it.Checked = $true
        $lv.Items.Add($it) | Out-Null
        $addedPrefixes[$p] = $true
    }
    # interfaces detectadas (apenas se prefixo novo)
    if ($ifaces) {
        foreach ($i in $ifaces) {
            if ($addedPrefixes.ContainsKey($i.Prefix)) { continue }
            $it = New-Object System.Windows.Forms.ListViewItem("$($i.Prefix).x")
            $it.SubItems.Add($i.Name) | Out-Null
            $it.SubItems.Add($i.Desc) | Out-Null
            $it.SubItems.Add($(if ($i.IsVirt) { "virtual" } else { "real" })) | Out-Null
            $it.Checked = (-not $i.IsVirt)
            $lv.Items.Add($it) | Out-Null
            $addedPrefixes[$i.Prefix] = $true
        }
    }
    $f.Controls.Add($lv)

    $lblCust = New-Object System.Windows.Forms.Label
    $lblCust.Text = "Adicionar subrede extra (ex: 192.168.100):"
    $lblCust.Location = New-Object System.Drawing.Point(15, 318); $lblCust.Size = New-Object System.Drawing.Size(250, 22)
    $f.Controls.Add($lblCust)
    $tbCust = New-Object System.Windows.Forms.TextBox
    $tbCust.Location = New-Object System.Drawing.Point(270, 315); $tbCust.Size = New-Object System.Drawing.Size(180, 24)
    $f.Controls.Add($tbCust)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = "Escanear"; $ok.Location = New-Object System.Drawing.Point(460, 355); $ok.Size = New-Object System.Drawing.Size(85, 30)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $f.AcceptButton = $ok; $f.Controls.Add($ok)
    $cc = New-Object System.Windows.Forms.Button
    $cc.Text = "Cancelar"; $cc.Location = New-Object System.Drawing.Point(550, 355); $cc.Size = New-Object System.Drawing.Size(85, 30)
    $cc.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $f.CancelButton = $cc; $f.Controls.Add($cc)

    $f.Topmost = $true
    if ($f.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return @() }

    $prefixes = @()
    foreach ($it in $lv.Items) {
        if ($it.Checked) {
            $p = $it.Text -replace '\.x$',''
            if ($p -match '^\d+\.\d+\.\d+$') { $prefixes += $p }
        }
    }
    if ($tbCust.Text.Trim()) {
        $p = $tbCust.Text.Trim() -replace '\.$',''
        if ($p -match '^\d+\.\d+\.\d+$') { $prefixes += $p }
        else { Show-Error "Subrede manual invalida: '$p'" }
    }
    $prefixes = $prefixes | Select-Object -Unique
    if ($prefixes.Count -eq 0) {
        Show-Error "Nenhuma subrede selecionada."
        return @()
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Descobrindo Ollama na rede..."
    $form.Size = New-Object System.Drawing.Size(480, 170)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.ControlBox = $false
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Iniciando..."
    $lbl.Location = New-Object System.Drawing.Point(20, 20); $lbl.Size = New-Object System.Drawing.Size(420, 40)
    $form.Controls.Add($lbl)
    $pb = New-Object System.Windows.Forms.ProgressBar
    $pb.Location = New-Object System.Drawing.Point(20, 70); $pb.Size = New-Object System.Drawing.Size(420, 20)
    $pb.Style = "Continuous"; $pb.Minimum = 0; $pb.Maximum = ($prefixes.Count * 254)
    $form.Controls.Add($pb)
    $lblFound = New-Object System.Windows.Forms.Label
    $lblFound.Text = "Encontrados: 0"
    $lblFound.Location = New-Object System.Drawing.Point(20, 100); $lblFound.Size = New-Object System.Drawing.Size(420, 22)
    $form.Controls.Add($lblFound)
    $form.Show(); $form.Refresh()

    $found = @()
    $idx = 0
    foreach ($prefix in $prefixes) {
        $lbl.Text = "Varrendo $prefix.1-254 porta 11434..."
        [System.Windows.Forms.Application]::DoEvents()
        foreach ($i in 1..254) {
            $idx++
            $pb.Value = $idx
            if ($i % 10 -eq 0) { [System.Windows.Forms.Application]::DoEvents() }
            $ip = "$prefix.$i"
            $client = New-Object System.Net.Sockets.TcpClient
            try {
                $task = $client.ConnectAsync($ip, 11434)
                if ($task.Wait(150)) {
                    if ($client.Connected) {
                        $client.Close()
                        if (Test-OllamaServer "http://${ip}:11434") {
                            $found += "http://${ip}:11434"
                            $lblFound.Text = "Encontrados: $($found.Count) - " + ($found -join ", ")
                        }
                    }
                }
            } catch { } finally { $client.Dispose() }
        }
    }
    $form.Close()
    return $found
}

# ============================================================
# BENCHMARK DE MODELO (item 8)
# ============================================================
function Benchmark-OllamaModel($ollamaUrl, $modelName) {
    $prompt = "Explique em 3 paragrafos o que e uma API REST."
    $body = @{ model = $modelName; prompt = $prompt; stream = $false } | ConvertTo-Json
    try {
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        $resp = Invoke-RestMethod -Uri "$ollamaUrl/api/generate" -Method Post -Body $body -ContentType "application/json" -TimeoutSec 300
        $sw.Stop()
        $totalSec = $sw.Elapsed.TotalSeconds
        $evalCount = $resp.eval_count
        $evalSec = $resp.eval_duration / 1e9
        $tps = if ($evalSec -gt 0) { [math]::Round($evalCount / $evalSec, 2) } else { 0 }
        return @{
            success   = $true
            totalSec  = [math]::Round($totalSec, 2)
            tokens    = $evalCount
            tps       = $tps
            loadSec   = [math]::Round($resp.load_duration / 1e9, 2)
        }
    } catch {
        return @{ success = $false; error = $_.Exception.Message }
    }
}

# ============================================================
# EDITOR DE PARAMETROS AVANCADOS (item 10)
# ============================================================
function Edit-AdvancedParams($current) {
    $f = New-Object System.Windows.Forms.Form
    $f.Text = "Parametros avancados (opcional)"
    $f.Size = New-Object System.Drawing.Size(760, 460)
    $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
    $f.MaximizeBox = $false; $f.MinimizeBox = $false

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Controlam o comportamento da LLM. Valores abaixo ja sao os padroes do Ollama.`nSalvos no settings.json como CLAUDE_OLLAMA_* (forwarding depende do CLI)."
    $lbl.Location = New-Object System.Drawing.Point(15, 10); $lbl.Size = New-Object System.Drawing.Size(720, 40)
    $f.Controls.Add($lbl)

    $makeRow = {
        param($label, $y, $default, $hint)
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $label; $l.Location = New-Object System.Drawing.Point(15, $y); $l.Size = New-Object System.Drawing.Size(120, 22)
        $l.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
        $f.Controls.Add($l)
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.Location = New-Object System.Drawing.Point(140, $y); $tb.Size = New-Object System.Drawing.Size(100, 22)
        $tb.Text = $default
        $f.Controls.Add($tb)
        $h = New-Object System.Windows.Forms.Label
        $h.Text = $hint; $h.Location = New-Object System.Drawing.Point(250, $y); $h.Size = New-Object System.Drawing.Size(490, 40)
        $h.ForeColor = [System.Drawing.Color]::DimGray
        $h.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $f.Controls.Add($h)
        return $tb
    }

    $tbTemp = & $makeRow "Temperature:" 60 $(if ($current.temperature) { "$($current.temperature)" } else { "0.7" }) `
        "Criatividade da resposta. 0.0 = deterministico (sempre igual, bom para codigo).`n1.0 = padrao. 2.0 = muito criativo (inventa coisas). Para codigo use 0.2-0.5."
    $tbTopP = & $makeRow "Top-P:" 110 $(if ($current.top_p) { "$($current.top_p)" } else { "0.9" }) `
        "Filtro de tokens: considera so os mais provaveis ate somar essa probabilidade.`n0.9 = padrao. Menor = mais focado. Maior = mais variedade."
    $tbCtx = & $makeRow "Num CTX:" 160 $(if ($current.num_ctx) { "$($current.num_ctx)" } else { "8192" }) `
        "Tamanho da janela de contexto (quantos tokens a LLM ve de uma vez).`n8192 = padrao. Maiores (32K, 128K) usam mais RAM/VRAM. O modelo tem limite proprio."
    $tbSeed = & $makeRow "Seed:" 210 $(if ($current.seed) { "$($current.seed)" } else { "" }) `
        "Semente aleatoria. Fixar um numero (ex: 42) faz o modelo dar a MESMA resposta sempre.`nUtil para testes/debug. Deixe vazio para respostas normais (aleatorias)."
    $tbSys = & $makeRow "System msg:" 260 $(if ($current.system) { "$($current.system)" } else { "" }) `
        "Instrucao base injetada antes de cada conversa (ex: 'Voce e um programador Python senior.').`nDeixe vazio se ja tiver CLAUDE.md ou nao quiser customizar."

    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = "Salvar"; $ok.Location = New-Object System.Drawing.Point(540, 370); $ok.Size = New-Object System.Drawing.Size(95, 32)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $f.AcceptButton = $ok; $f.Controls.Add($ok)
    $cc = New-Object System.Windows.Forms.Button
    $cc.Text = "Pular / Cancelar"; $cc.Location = New-Object System.Drawing.Point(640, 370); $cc.Size = New-Object System.Drawing.Size(95, 32)
    $cc.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $f.CancelButton = $cc; $f.Controls.Add($cc)

    $f.Topmost = $true
    if ($f.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }

    $out = @{}
    if ($tbTemp.Text.Trim()) { $out.temperature = $tbTemp.Text.Trim() }
    if ($tbTopP.Text.Trim()) { $out.top_p       = $tbTopP.Text.Trim() }
    if ($tbCtx.Text.Trim())  { $out.num_ctx     = $tbCtx.Text.Trim() }
    if ($tbSeed.Text.Trim()) { $out.seed        = $tbSeed.Text.Trim() }
    if ($tbSys.Text.Trim())  { $out.system      = $tbSys.Text.Trim() }
    if ($out.Count -eq 0) { return $null }
    return $out
}

function Delete-OllamaModel($ollamaUrl, $modelName) {
    $body = @{ name = $modelName } | ConvertTo-Json
    Invoke-RestMethod -Uri "$ollamaUrl/api/delete" -Method Delete -Body $body -ContentType "application/json" -TimeoutSec 30
}

function Pull-OllamaModel($ollamaUrl, $modelName) {
    # Abre janela separada com curl -N mostrando progresso em streaming
    $cmd = "curl.exe -N -X POST `"$ollamaUrl/api/pull`" -H `"Content-Type: application/json`" -d `"{\`"name\`":\`"$modelName\`"}`""
    $psCmd = "Write-Host 'Baixando $modelName de $ollamaUrl' -ForegroundColor Cyan; Write-Host ''; $cmd; Write-Host ''; Read-Host 'Pressione ENTER para fechar'"
    Start-Process powershell -ArgumentList '-NoProfile','-NoExit','-Command',$psCmd
}

# ============================================================
# SELECT MODEL (usada em varios fluxos)
# ============================================================
function Select-Model($models, $title, $subtitle, $okLabel = "OK") {
    if (-not $models -or $models.Count -eq 0) {
        Show-Error "Nenhum modelo disponivel no servidor."
        return $null
    }
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $title
    $f.Size = New-Object System.Drawing.Size(620, 480)
    $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
    $f.MaximizeBox = $false; $f.MinimizeBox = $false

    $lb = New-Object System.Windows.Forms.Label
    $lb.Text = $subtitle; $lb.Location = New-Object System.Drawing.Point(10, 10)
    $lb.Size = New-Object System.Drawing.Size(590, 60); $lb.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $f.Controls.Add($lb)

    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(10, 75)
    $lv.Size = New-Object System.Drawing.Size(590, 320)
    $lv.View = "Details"; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.MultiSelect = $false
    $lv.Font = New-Object System.Drawing.Font("Consolas", 10)
    $lv.Columns.Add("Modelo", 230) | Out-Null
    $lv.Columns.Add("Parametros", 100) | Out-Null
    $lv.Columns.Add("Tamanho", 90) | Out-Null
    $lv.Columns.Add("Familia", 90) | Out-Null
    $lv.Columns.Add("Quant", 70) | Out-Null
    foreach ($m in $models) {
        $item = New-Object System.Windows.Forms.ListViewItem($m.Name)
        $item.SubItems.Add($m.Parameters) | Out-Null
        $item.SubItems.Add("$($m.SizeGB) GB") | Out-Null
        $item.SubItems.Add($m.Family) | Out-Null
        $item.SubItems.Add($m.Quant) | Out-Null
        $lv.Items.Add($item) | Out-Null
    }
    $lv.Items[0].Selected = $true; $f.Controls.Add($lv)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = $okLabel; $ok.Location = New-Object System.Drawing.Point(410, 405)
    $ok.Size = New-Object System.Drawing.Size(95, 30)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $f.AcceptButton = $ok; $f.Controls.Add($ok)

    $cc = New-Object System.Windows.Forms.Button
    $cc.Text = "Cancelar"; $cc.Location = New-Object System.Drawing.Point(510, 405)
    $cc.Size = New-Object System.Drawing.Size(90, 30)
    $cc.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $f.CancelButton = $cc; $f.Controls.Add($cc)

    $lv.Add_DoubleClick({ $f.DialogResult = [System.Windows.Forms.DialogResult]::OK; $f.Close() })
    $f.Topmost = $true
    if ($f.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    if ($lv.SelectedItems.Count -eq 0) { return $null }
    return $lv.SelectedItems[0].Text
}

# ============================================================
# SELECT TWO MODELS (principal + rapido)
# ============================================================
function Select-TwoModels($models, $currentMain, $currentFast) {
    $f = New-Object System.Windows.Forms.Form
    $f.Text = "Escolha os modelos"
    $f.Size = New-Object System.Drawing.Size(680, 560)
    $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
    $f.MaximizeBox = $false; $f.MinimizeBox = $false

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "MODELO PRINCIPAL - usado pelo Claude para codigo, raciocinio, chats longos."
    $lbl.Location = New-Object System.Drawing.Point(10, 10)
    $lbl.Size = New-Object System.Drawing.Size(650, 20)
    $lbl.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $f.Controls.Add($lbl)

    $cbMain = New-Object System.Windows.Forms.ComboBox
    $cbMain.Location = New-Object System.Drawing.Point(10, 35)
    $cbMain.Size = New-Object System.Drawing.Size(650, 28)
    $cbMain.DropDownStyle = "DropDownList"
    $cbMain.Font = New-Object System.Drawing.Font("Consolas", 10)
    foreach ($m in $models) { [void]$cbMain.Items.Add("$($m.Name)  ($($m.Parameters), $($m.SizeGB) GB)") }
    $f.Controls.Add($cbMain)

    # selecionar default
    if ($currentMain) {
        for ($i = 0; $i -lt $cbMain.Items.Count; $i++) {
            if ($cbMain.Items[$i] -match "^$([regex]::Escape($currentMain))\s") { $cbMain.SelectedIndex = $i; break }
        }
    }
    if ($cbMain.SelectedIndex -lt 0) { $cbMain.SelectedIndex = 0 }

    $lbl2 = New-Object System.Windows.Forms.Label
    $lbl2.Text = "MODELO RAPIDO - usado para tarefas leves (sumarios, autocomplete). Pode ser o mesmo."
    $lbl2.Location = New-Object System.Drawing.Point(10, 80)
    $lbl2.Size = New-Object System.Drawing.Size(650, 20)
    $lbl2.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $f.Controls.Add($lbl2)

    $chkSame = New-Object System.Windows.Forms.CheckBox
    $chkSame.Text = "Usar o mesmo modelo principal"
    $chkSame.Location = New-Object System.Drawing.Point(10, 105)
    $chkSame.Size = New-Object System.Drawing.Size(300, 22)
    $chkSame.Checked = ($currentMain -eq $currentFast -or -not $currentFast)
    $f.Controls.Add($chkSame)

    $cbFast = New-Object System.Windows.Forms.ComboBox
    $cbFast.Location = New-Object System.Drawing.Point(10, 132)
    $cbFast.Size = New-Object System.Drawing.Size(650, 28)
    $cbFast.DropDownStyle = "DropDownList"
    $cbFast.Font = New-Object System.Drawing.Font("Consolas", 10)
    foreach ($m in $models) { [void]$cbFast.Items.Add("$($m.Name)  ($($m.Parameters), $($m.SizeGB) GB)") }
    $f.Controls.Add($cbFast)

    if ($currentFast) {
        for ($i = 0; $i -lt $cbFast.Items.Count; $i++) {
            if ($cbFast.Items[$i] -match "^$([regex]::Escape($currentFast))\s") { $cbFast.SelectedIndex = $i; break }
        }
    }
    if ($cbFast.SelectedIndex -lt 0) { $cbFast.SelectedIndex = $cbMain.SelectedIndex }
    $cbFast.Enabled = -not $chkSame.Checked
    $chkSame.Add_CheckedChanged({ $cbFast.Enabled = -not $chkSame.Checked })

    $lbl3 = New-Object System.Windows.Forms.Label
    $lbl3.Text = "Lista completa (referencia):"
    $lbl3.Location = New-Object System.Drawing.Point(10, 175)
    $lbl3.Size = New-Object System.Drawing.Size(650, 20)
    $f.Controls.Add($lbl3)

    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(10, 198)
    $lv.Size = New-Object System.Drawing.Size(650, 275)
    $lv.View = "Details"; $lv.FullRowSelect = $true; $lv.GridLines = $true
    $lv.Font = New-Object System.Drawing.Font("Consolas", 9)
    $lv.Columns.Add("Modelo", 260) | Out-Null
    $lv.Columns.Add("Parametros", 100) | Out-Null
    $lv.Columns.Add("Tamanho", 90) | Out-Null
    $lv.Columns.Add("Familia", 100) | Out-Null
    $lv.Columns.Add("Quant", 85) | Out-Null
    foreach ($m in $models) {
        $item = New-Object System.Windows.Forms.ListViewItem($m.Name)
        $item.SubItems.Add($m.Parameters) | Out-Null
        $item.SubItems.Add("$($m.SizeGB) GB") | Out-Null
        $item.SubItems.Add($m.Family) | Out-Null
        $item.SubItems.Add($m.Quant) | Out-Null
        $lv.Items.Add($item) | Out-Null
    }
    $f.Controls.Add($lv)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = "Confirmar"
    $ok.Location = New-Object System.Drawing.Point(470, 485)
    $ok.Size = New-Object System.Drawing.Size(90, 30)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $f.AcceptButton = $ok; $f.Controls.Add($ok)

    $cc = New-Object System.Windows.Forms.Button
    $cc.Text = "Cancelar"
    $cc.Location = New-Object System.Drawing.Point(570, 485)
    $cc.Size = New-Object System.Drawing.Size(90, 30)
    $cc.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $f.CancelButton = $cc; $f.Controls.Add($cc)

    $f.Topmost = $true
    if ($f.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }

    $mainName = ($cbMain.SelectedItem -split '\s')[0]
    if ($chkSame.Checked) { $fastName = $mainName } else { $fastName = ($cbFast.SelectedItem -split '\s')[0] }
    return @{ main = $mainName; fast = $fastName }
}

# ============================================================
# WRITE SETTINGS (com 2 modelos)
# ============================================================
function Write-OllamaSettings($targetFolder, $ollamaUrl, $mainModel, $fastModel, $params) {
    $claudeDir    = Join-Path $targetFolder ".claude"
    $settingsPath = Join-Path $claudeDir "settings.json"
    if (-not (Test-Path $claudeDir)) { New-Item -ItemType Directory -Path $claudeDir -Force | Out-Null }

    $ollamaEnv = [ordered]@{
        ANTHROPIC_BASE_URL         = $ollamaUrl
        ANTHROPIC_AUTH_TOKEN       = "ollama"
        ANTHROPIC_MODEL            = $mainModel
        ANTHROPIC_SMALL_FAST_MODEL = $fastModel
        DISABLE_TELEMETRY          = "1"
        DISABLE_ERROR_REPORTING    = "1"
    }
    if ($params) {
        foreach ($k in $params.Keys) {
            $ollamaEnv["CLAUDE_OLLAMA_$($k.ToUpper())"] = "$($params[$k])"
        }
    }

    if (Test-Path $settingsPath) {
        $backupPath = "$settingsPath.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item $settingsPath $backupPath
        try { $existing = Get-Content $settingsPath -Raw | ConvertFrom-Json -AsHashtable } catch { $existing = @{} }
        if (-not $existing) { $existing = @{} }
        if (-not $existing.ContainsKey('env') -or $null -eq $existing['env']) { $existing['env'] = @{} }
        foreach ($k in $ollamaEnv.Keys) { $existing['env'][$k] = $ollamaEnv[$k] }
        $existing['model'] = $mainModel
        $merged = $existing
    } else {
        $merged = [ordered]@{ env = $ollamaEnv; model = $mainModel }
    }
    $merged | ConvertTo-Json -Depth 10 | Set-Content -Path $settingsPath -Encoding UTF8

    $envPath = Join-Path $targetFolder ".env"
    $envContent = @"
ANTHROPIC_BASE_URL=$ollamaUrl
ANTHROPIC_AUTH_TOKEN=ollama
ANTHROPIC_MODEL=$mainModel
ANTHROPIC_SMALL_FAST_MODEL=$fastModel
"@
    Set-Content -Path $envPath -Value $envContent -Encoding UTF8
}

# ============================================================
# LAUNCH CLI (claude ou openclaude)
# ============================================================
function Launch-CLI($cliCommand, $targetFolder, $ollamaUrl, $mainModel, $fastModel) {
    $cliExe = Get-Command $cliCommand -ErrorAction SilentlyContinue
    if (-not $cliExe) {
        Show-Error "Comando '$cliCommand' nao encontrado no PATH."
        return $false
    }
    # Item 13: validar que os modelos existem no servidor antes de abrir
    $serverModels = Get-OllamaModels $ollamaUrl
    if ($serverModels) {
        $names = @($serverModels | ForEach-Object { $_.Name })
        $missing = @()
        if ($names -notcontains $mainModel) { $missing += "principal: $mainModel" }
        if ($fastModel -and $names -notcontains $fastModel) { $missing += "rapido: $fastModel" }
        if ($missing.Count -gt 0) {
            $msg = "Modelos ausentes no servidor $ollamaUrl`:`n" + ($missing -join "`n") + "`n`nAbrir mesmo assim?"
            if (-not (Ask-YesNo $msg "Modelos ausentes")) {
                Write-LauncherLog "launch-aborted" "missing=$($missing -join ',') folder=$targetFolder"
                return $false
            }
        }
    }
    Write-LauncherLog "launch" "cli=$cliCommand main=$mainModel fast=$fastModel server=$ollamaUrl folder=$targetFolder"
    $configDir = Join-Path $targetFolder ".claude-home"
    Set-Location $targetFolder
    $env:CLAUDE_CONFIG_DIR           = $configDir
    $env:ANTHROPIC_BASE_URL          = $ollamaUrl
    $env:ANTHROPIC_AUTH_TOKEN        = "ollama"
    $env:ANTHROPIC_MODEL             = $mainModel
    $env:ANTHROPIC_SMALL_FAST_MODEL  = $fastModel
    Remove-Item Env:ANTHROPIC_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:CLAUDE_CODE_OAUTH_TOKEN -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host "===================================================" -ForegroundColor Cyan
    Write-Host " Abrindo: $($cliCommand.ToUpper())"                  -ForegroundColor Cyan
    Write-Host " Principal: $mainModel"                              -ForegroundColor Cyan
    Write-Host " Rapido:    $fastModel"                              -ForegroundColor Cyan
    Write-Host " Servidor: $ollamaUrl"                               -ForegroundColor Cyan
    Write-Host " Pasta:    $targetFolder"                            -ForegroundColor Cyan
    Write-Host "===================================================" -ForegroundColor Cyan
    Write-Host ""

    # Abre o CLI em uma nova janela de console (novo pwsh/cmd) para garantir TTY interativo.
    # O launcher continua rodando; fechar o CLI nao fecha o launcher.
    $cliPath = (Get-Command $cliCommand -ErrorAction SilentlyContinue).Source
    if (-not $cliPath) { $cliPath = $cliCommand }

    $envBlock = @"
`$env:CLAUDE_CONFIG_DIR = '$configDir'
`$env:ANTHROPIC_BASE_URL = '$ollamaUrl'
`$env:ANTHROPIC_AUTH_TOKEN = 'ollama'
`$env:ANTHROPIC_MODEL = '$mainModel'
`$env:ANTHROPIC_SMALL_FAST_MODEL = '$fastModel'
Remove-Item Env:ANTHROPIC_API_KEY -ErrorAction SilentlyContinue
Remove-Item Env:CLAUDE_CODE_OAUTH_TOKEN -ErrorAction SilentlyContinue
Set-Location '$targetFolder'
& '$cliPath' --model '$mainModel'
"@
    $tmpScript = Join-Path $env:TEMP "claude-ollama-launch-$([guid]::NewGuid().ToString('N')).ps1"
    Set-Content -Path $tmpScript -Value $envBlock -Encoding UTF8

    $pwshExe = (Get-Command pwsh -ErrorAction SilentlyContinue).Source
    if (-not $pwshExe) { $pwshExe = "powershell" }

    Start-Process -FilePath $pwshExe -ArgumentList @("-NoProfile","-NoExit","-ExecutionPolicy","Bypass","-File",$tmpScript) -WorkingDirectory $targetFolder
    return $true
}

# ============================================================
# UI: GERENCIAR SERVIDORES
# ============================================================
function Manage-Servers($cfg) {
    while ($true) {
        $f = New-Object System.Windows.Forms.Form
        $f.Text = "Gerenciar servidores Ollama"
        $f.Size = New-Object System.Drawing.Size(600, 400)
        $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
        $f.MaximizeBox = $false; $f.MinimizeBox = $false

        $lv = New-Object System.Windows.Forms.ListView
        $lv.Location = New-Object System.Drawing.Point(10, 10); $lv.Size = New-Object System.Drawing.Size(570, 260)
        $lv.View = "Details"; $lv.FullRowSelect = $true; $lv.GridLines = $true
        $lv.Columns.Add("Nome", 130) | Out-Null
        $lv.Columns.Add("URL", 330) | Out-Null
        $lv.Columns.Add("Padrao", 80) | Out-Null
        foreach ($name in $cfg.servers.Keys) {
            $it = New-Object System.Windows.Forms.ListViewItem($name)
            $it.SubItems.Add($cfg.servers[$name]) | Out-Null
            $it.SubItems.Add($(if ($name -eq $cfg.defaultServer) { "sim" } else { "" })) | Out-Null
            $lv.Items.Add($it) | Out-Null
        }
        if ($lv.Items.Count -gt 0) { $lv.Items[0].Selected = $true }
        $f.Controls.Add($lv)

        $btnAdd = New-Object System.Windows.Forms.Button
        $btnAdd.Text = "Adicionar"; $btnAdd.Location = New-Object System.Drawing.Point(10, 285); $btnAdd.Size = New-Object System.Drawing.Size(90, 35)
        $btnAdd.Add_Click({ $f.Tag = "add"; $f.Close() })
        $f.Controls.Add($btnAdd)

        $btnEdit = New-Object System.Windows.Forms.Button
        $btnEdit.Text = "Editar"; $btnEdit.Location = New-Object System.Drawing.Point(105, 285); $btnEdit.Size = New-Object System.Drawing.Size(90, 35)
        $btnEdit.Add_Click({ $f.Tag = "edit"; $f.Close() })
        $f.Controls.Add($btnEdit)

        $btnDel = New-Object System.Windows.Forms.Button
        $btnDel.Text = "Remover"; $btnDel.Location = New-Object System.Drawing.Point(200, 285); $btnDel.Size = New-Object System.Drawing.Size(90, 35)
        $btnDel.Add_Click({ $f.Tag = "del"; $f.Close() })
        $f.Controls.Add($btnDel)

        $btnDef = New-Object System.Windows.Forms.Button
        $btnDef.Text = "Definir padrao"; $btnDef.Location = New-Object System.Drawing.Point(295, 285); $btnDef.Size = New-Object System.Drawing.Size(110, 35)
        $btnDef.Add_Click({ $f.Tag = "default"; $f.Close() })
        $f.Controls.Add($btnDef)

        $btnTest = New-Object System.Windows.Forms.Button
        $btnTest.Text = "Testar"; $btnTest.Location = New-Object System.Drawing.Point(410, 285); $btnTest.Size = New-Object System.Drawing.Size(80, 35)
        $btnTest.Add_Click({ $f.Tag = "test"; $f.Close() })
        $f.Controls.Add($btnTest)

        $btnDisc = New-Object System.Windows.Forms.Button
        $btnDisc.Text = "Descobrir na rede"; $btnDisc.Location = New-Object System.Drawing.Point(10, 325); $btnDisc.Size = New-Object System.Drawing.Size(140, 30)
        $btnDisc.Add_Click({ $f.Tag = "discover"; $f.Close() })
        $f.Controls.Add($btnDisc)

        $btnClose = New-Object System.Windows.Forms.Button
        $btnClose.Text = "Fechar"; $btnClose.Location = New-Object System.Drawing.Point(495, 285); $btnClose.Size = New-Object System.Drawing.Size(85, 35)
        $btnClose.Add_Click({ $f.Tag = "close"; $f.Close() })
        $f.Controls.Add($btnClose)

        $f.Topmost = $true; $f.ShowDialog() | Out-Null
        $selName = $null
        if ($lv.SelectedItems.Count -gt 0) { $selName = $lv.SelectedItems[0].Text }

        switch ($f.Tag) {
            "add" {
                $name = Ask-Input "Nome do servidor (apelido, ex: casa, trabalho):" "Adicionar servidor"
                if (-not $name) { continue }
                $url = Ask-Input "URL completa (ex: http://192.168.1.80:11434):" "Adicionar servidor" "http://"
                if (-not $url) { continue }
                $cfg.servers[$name] = $url
                Save-LauncherConfig $cfg
            }
            "edit" {
                if (-not $selName) { continue }
                $url = Ask-Input "Nova URL para '$selName':" "Editar servidor" $cfg.servers[$selName]
                if ($url) { $cfg.servers[$selName] = $url; Save-LauncherConfig $cfg }
            }
            "del" {
                if (-not $selName) { continue }
                if (Ask-YesNo "Remover servidor '$selName'?" "Confirmar") {
                    $cfg.servers.Remove($selName) | Out-Null
                    if ($cfg.defaultServer -eq $selName) {
                        $cfg.defaultServer = ($cfg.servers.Keys | Select-Object -First 1)
                    }
                    Save-LauncherConfig $cfg
                }
            }
            "default" {
                if (-not $selName) { continue }
                $cfg.defaultServer = $selName; Save-LauncherConfig $cfg
            }
            "test" {
                if (-not $selName) { continue }
                $url = $cfg.servers[$selName]
                if (Test-OllamaServer $url) { Show-Info "OK - $url respondeu." "Teste de conexao" }
                else { Show-Error "Falha - $url nao respondeu." }
            }
            "discover" {
                $urls = Find-OllamaServers
                if ($urls.Count -eq 0) {
                    Show-Info "Nenhum servidor Ollama encontrado na sua rede local." "Descoberta"
                } else {
                    $msg = "Encontrados:`n" + ($urls -join "`n") + "`n`nAdicionar todos ao perfil?"
                    if (Ask-YesNo $msg "Servidores encontrados") {
                        foreach ($u in $urls) {
                            $name = "auto-" + (($u -replace 'http://','') -replace ':.*','')
                            $cfg.servers[$name] = $u
                        }
                        Save-LauncherConfig $cfg
                    }
                }
            }
            default { return $cfg }
        }
    }
}

# ============================================================
# UI: GERENCIAR MODELOS NO SERVIDOR (pull/delete)
# ============================================================
function Manage-Models($ollamaUrl) {
    while ($true) {
        $models = Get-OllamaModels $ollamaUrl
        if ($null -eq $models) { return }

        $f = New-Object System.Windows.Forms.Form
        $f.Text = "Modelos no servidor - $ollamaUrl"
        $f.Size = New-Object System.Drawing.Size(680, 480)
        $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
        $f.MaximizeBox = $false; $f.MinimizeBox = $false

        $lv = New-Object System.Windows.Forms.ListView
        $lv.Location = New-Object System.Drawing.Point(10, 10); $lv.Size = New-Object System.Drawing.Size(650, 360)
        $lv.View = "Details"; $lv.FullRowSelect = $true; $lv.GridLines = $true
        $lv.Font = New-Object System.Drawing.Font("Consolas", 10)
        $lv.Columns.Add("Modelo", 260) | Out-Null
        $lv.Columns.Add("Parametros", 100) | Out-Null
        $lv.Columns.Add("Tamanho", 90) | Out-Null
        $lv.Columns.Add("Familia", 100) | Out-Null
        $lv.Columns.Add("Quant", 85) | Out-Null
        foreach ($m in $models) {
            $it = New-Object System.Windows.Forms.ListViewItem($m.Name)
            $it.SubItems.Add($m.Parameters) | Out-Null
            $it.SubItems.Add("$($m.SizeGB) GB") | Out-Null
            $it.SubItems.Add($m.Family) | Out-Null
            $it.SubItems.Add($m.Quant) | Out-Null
            $lv.Items.Add($it) | Out-Null
        }
        $f.Controls.Add($lv)

        $btnPull = New-Object System.Windows.Forms.Button
        $btnPull.Text = "Baixar novo (Pull)"
        $btnPull.Location = New-Object System.Drawing.Point(10, 385); $btnPull.Size = New-Object System.Drawing.Size(140, 35)
        $btnPull.Add_Click({ $f.Tag = "pull"; $f.Close() })
        $f.Controls.Add($btnPull)

        $btnDel = New-Object System.Windows.Forms.Button
        $btnDel.Text = "Remover selecionado"
        $btnDel.Location = New-Object System.Drawing.Point(155, 385); $btnDel.Size = New-Object System.Drawing.Size(160, 35)
        $btnDel.Add_Click({ $f.Tag = "delete"; $f.Close() })
        $f.Controls.Add($btnDel)

        $btnRefresh = New-Object System.Windows.Forms.Button
        $btnRefresh.Text = "Atualizar lista"
        $btnRefresh.Location = New-Object System.Drawing.Point(320, 385); $btnRefresh.Size = New-Object System.Drawing.Size(120, 35)
        $btnRefresh.Add_Click({ $f.Tag = "refresh"; $f.Close() })
        $f.Controls.Add($btnRefresh)

        $btnBench = New-Object System.Windows.Forms.Button
        $btnBench.Text = "Benchmark"
        $btnBench.Location = New-Object System.Drawing.Point(445, 385); $btnBench.Size = New-Object System.Drawing.Size(120, 35)
        $btnBench.Add_Click({ $f.Tag = "bench"; $f.Close() })
        $f.Controls.Add($btnBench)

        $btnClose = New-Object System.Windows.Forms.Button
        $btnClose.Text = "Fechar"
        $btnClose.Location = New-Object System.Drawing.Point(575, 385); $btnClose.Size = New-Object System.Drawing.Size(85, 35)
        $btnClose.Add_Click({ $f.Tag = "close"; $f.Close() })
        $f.Controls.Add($btnClose)

        $f.Topmost = $true; $f.ShowDialog() | Out-Null

        switch ($f.Tag) {
            "pull" {
                $name = Ask-Input "Nome do modelo para baixar (ex: llama3.2, qwen3.5:27b):" "Pull de modelo"
                if ($name) {
                    Pull-OllamaModel $ollamaUrl $name
                    Show-Info "Download iniciado em janela separada.`nAguarde concluir e volte aqui para 'Atualizar lista'." "Pull iniciado"
                }
            }
            "delete" {
                if ($lv.SelectedItems.Count -eq 0) { continue }
                $name = $lv.SelectedItems[0].Text
                if (Ask-YesNo "Remover modelo '$name' do servidor?`n(Libera disco no servidor - nao afeta pastas ja configuradas)" "Confirmar remocao") {
                    try {
                        Delete-OllamaModel $ollamaUrl $name
                        Show-Info "Modelo '$name' removido." "OK"
                    } catch {
                        Show-Error "Falha ao remover: $($_.Exception.Message)"
                    }
                }
            }
            "refresh" { }
            "bench" {
                if ($lv.SelectedItems.Count -eq 0) { continue }
                $name = $lv.SelectedItems[0].Text
                Show-Info "Rodando benchmark em '$name'. Pode levar ate 1 min..." "Benchmark"
                $r = Benchmark-OllamaModel $ollamaUrl $name
                if ($r.success) {
                    $msg = "Modelo: $name`nTempo total: $($r.totalSec)s`nCarregamento: $($r.loadSec)s`nTokens gerados: $($r.tokens)`nVelocidade: $($r.tps) tokens/s"
                    Show-Info $msg "Benchmark - $name"
                    Write-LauncherLog "benchmark" "model=$name tps=$($r.tps) total=$($r.totalSec)s"
                } else {
                    Show-Error "Falha: $($r.error)"
                }
            }
            default { return }
        }
    }
}

# ============================================================
# MAIN MENU (com dropdown de servidor + pastas recentes)
# ============================================================
function Show-MainMenu($cfg) {
    $f = New-Object System.Windows.Forms.Form
    $f.Text = "Claude + Ollama Launcher"
    $f.Size = New-Object System.Drawing.Size(820, 540)
    $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
    $f.MaximizeBox = $false; $f.MinimizeBox = $true

    # Linha do servidor
    $lblSrv = New-Object System.Windows.Forms.Label
    $lblSrv.Text = "Servidor Ollama:"
    $lblSrv.Location = New-Object System.Drawing.Point(15, 20); $lblSrv.Size = New-Object System.Drawing.Size(120, 22)
    $lblSrv.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $f.Controls.Add($lblSrv)

    $cbSrv = New-Object System.Windows.Forms.ComboBox
    $cbSrv.Location = New-Object System.Drawing.Point(140, 18); $cbSrv.Size = New-Object System.Drawing.Size(430, 26)
    $cbSrv.DropDownStyle = "DropDownList"; $cbSrv.Font = New-Object System.Drawing.Font("Consolas", 10)
    foreach ($name in $cfg.servers.Keys) { [void]$cbSrv.Items.Add("$name   -   $($cfg.servers[$name])") }
    for ($i = 0; $i -lt $cbSrv.Items.Count; $i++) {
        if ($cbSrv.Items[$i] -match "^$([regex]::Escape($cfg.defaultServer))\s+-") { $cbSrv.SelectedIndex = $i; break }
    }
    if ($cbSrv.SelectedIndex -lt 0 -and $cbSrv.Items.Count -gt 0) { $cbSrv.SelectedIndex = 0 }
    $f.Controls.Add($cbSrv)

    $btnMgSrv = New-Object System.Windows.Forms.Button
    $btnMgSrv.Text = "Gerenciar..."; $btnMgSrv.Location = New-Object System.Drawing.Point(580, 17); $btnMgSrv.Size = New-Object System.Drawing.Size(100, 28)
    $btnMgSrv.Add_Click({ $f.Tag = "manage-servers"; $f.Close() })
    $f.Controls.Add($btnMgSrv)

    $btnMgMdl = New-Object System.Windows.Forms.Button
    $btnMgMdl.Text = "Modelos..."; $btnMgMdl.Location = New-Object System.Drawing.Point(690, 17); $btnMgMdl.Size = New-Object System.Drawing.Size(100, 28)
    $btnMgMdl.Add_Click({ $f.Tag = "manage-models"; $f.Close() })
    $f.Controls.Add($btnMgMdl)

    # linha do modelo padrao do servidor atual
    $currentSrvName = $cfg.defaultServer
    if ($cbSrv.SelectedIndex -ge 0) {
        $currentSrvName = ($cbSrv.SelectedItem -split '\s+-\s+')[0]
    }
    $currentDefault = if ($cfg.defaultModels.ContainsKey($currentSrvName)) { $cfg.defaultModels[$currentSrvName] } else { "(nenhum - sera perguntado)" }

    $lblDef = New-Object System.Windows.Forms.Label
    $lblDef.Text = "Modelo padrao desse servidor:"
    $lblDef.Location = New-Object System.Drawing.Point(15, 55)
    $lblDef.Size = New-Object System.Drawing.Size(200, 20)
    $f.Controls.Add($lblDef)

    $lblDefVal = New-Object System.Windows.Forms.Label
    $lblDefVal.Text = $currentDefault
    $lblDefVal.Location = New-Object System.Drawing.Point(220, 55)
    $lblDefVal.Size = New-Object System.Drawing.Size(340, 20)
    $lblDefVal.Font = New-Object System.Drawing.Font("Consolas", 9, [System.Drawing.FontStyle]::Bold)
    $lblDefVal.ForeColor = [System.Drawing.Color]::DarkGreen
    $f.Controls.Add($lblDefVal)

    $btnDefMdl = New-Object System.Windows.Forms.Button
    $btnDefMdl.Text = "Mudar padrao"
    $btnDefMdl.Location = New-Object System.Drawing.Point(570, 52); $btnDefMdl.Size = New-Object System.Drawing.Size(110, 26)
    $btnDefMdl.Add_Click({ $f.Tag = "set-default-model"; $f.Close() })
    $f.Controls.Add($btnDefMdl)

    # atualiza label quando muda servidor
    $cbSrv.Add_SelectedIndexChanged({
        $sel = ($cbSrv.SelectedItem -split '\s+-\s+')[0]
        if ($cfg.defaultModels.ContainsKey($sel)) { $lblDefVal.Text = $cfg.defaultModels[$sel] }
        else { $lblDefVal.Text = "(nenhum - sera perguntado)" }
    })

    # Acoes principais (coluna esquerda)
    $lblAcoes = New-Object System.Windows.Forms.Label
    $lblAcoes.Text = "Acoes"; $lblAcoes.Location = New-Object System.Drawing.Point(15, 105)
    $lblAcoes.Size = New-Object System.Drawing.Size(100, 20)
    $lblAcoes.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $f.Controls.Add($lblAcoes)

    $btnClaude = New-Object System.Windows.Forms.Button
    $btnClaude.Text = "Nova pasta + CLAUDE CLI"
    $btnClaude.Location = New-Object System.Drawing.Point(15, 130); $btnClaude.Size = New-Object System.Drawing.Size(330, 50)
    $btnClaude.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $btnClaude.Add_Click({ $f.Tag = "new:claude"; $f.Close() })
    $f.Controls.Add($btnClaude)

    $btnOpen = New-Object System.Windows.Forms.Button
    $btnOpen.Text = "Nova pasta + OPENCLAUDE"
    $btnOpen.Location = New-Object System.Drawing.Point(15, 190); $btnOpen.Size = New-Object System.Drawing.Size(330, 50)
    $btnOpen.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $btnOpen.Add_Click({ $f.Tag = "new:openclaude"; $f.Close() })
    $f.Controls.Add($btnOpen)

    $btnSwitch = New-Object System.Windows.Forms.Button
    $btnSwitch.Text = "Trocar modelo de pasta existente"
    $btnSwitch.Location = New-Object System.Drawing.Point(15, 250); $btnSwitch.Size = New-Object System.Drawing.Size(330, 50)
    $btnSwitch.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $btnSwitch.Add_Click({ $f.Tag = "switch"; $f.Close() })
    $f.Controls.Add($btnSwitch)

    $btnReset = New-Object System.Windows.Forms.Button
    $btnReset.Text = "Resetar pasta para Anthropic"
    $btnReset.Location = New-Object System.Drawing.Point(15, 310); $btnReset.Size = New-Object System.Drawing.Size(330, 50)
    $btnReset.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $btnReset.Add_Click({ $f.Tag = "reset"; $f.Close() })
    $f.Controls.Add($btnReset)

    # Pastas recentes (coluna direita)
    $lblRec = New-Object System.Windows.Forms.Label
    $lblRec.Text = "Pastas recentes (duplo-clique para abrir)"
    $lblRec.Location = New-Object System.Drawing.Point(365, 105); $lblRec.Size = New-Object System.Drawing.Size(425, 20)
    $lblRec.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $f.Controls.Add($lblRec)

    $lvRec = New-Object System.Windows.Forms.ListView
    $lvRec.Location = New-Object System.Drawing.Point(365, 130); $lvRec.Size = New-Object System.Drawing.Size(425, 340)
    $lvRec.View = "Details"; $lvRec.FullRowSelect = $true; $lvRec.GridLines = $true
    $lvRec.Font = New-Object System.Drawing.Font("Consolas", 9)
    $lvRec.Columns.Add("Pasta", 230) | Out-Null
    $lvRec.Columns.Add("Modelo", 110) | Out-Null
    $lvRec.Columns.Add("CLI", 75) | Out-Null
    foreach ($r in $cfg.recentFolders) {
        $leaf = Split-Path $r.path -Leaf
        $it = New-Object System.Windows.Forms.ListViewItem($leaf)
        $it.SubItems.Add($r.model) | Out-Null
        $it.SubItems.Add($r.cli) | Out-Null
        $it.ToolTipText = "$($r.path)`nServidor: $($r.server)`nRapido: $($r.fast)"
        $lvRec.Items.Add($it) | Out-Null
    }
    $lvRec.ShowItemToolTips = $true
    $lvRec.Add_DoubleClick({ $f.Tag = "recent"; $f.Close() })
    $f.Controls.Add($lvRec)

    # Acoes sobre recentes + utilitarios
    $btnRecOpen = New-Object System.Windows.Forms.Button
    $btnRecOpen.Text = "Reabrir"; $btnRecOpen.Location = New-Object System.Drawing.Point(15, 380); $btnRecOpen.Size = New-Object System.Drawing.Size(160, 32)
    $btnRecOpen.Add_Click({ $f.Tag = "recent"; $f.Close() })
    $f.Controls.Add($btnRecOpen)

    $btnRecDel = New-Object System.Windows.Forms.Button
    $btnRecDel.Text = "Remover da lista"; $btnRecDel.Location = New-Object System.Drawing.Point(185, 380); $btnRecDel.Size = New-Object System.Drawing.Size(160, 32)
    $btnRecDel.Add_Click({ $f.Tag = "recent-del"; $f.Close() })
    $f.Controls.Add($btnRecDel)

    $btnLog = New-Object System.Windows.Forms.Button
    $btnLog.Text = "Abrir launcher.log"
    $btnLog.Location = New-Object System.Drawing.Point(15, 420); $btnLog.Size = New-Object System.Drawing.Size(160, 32)
    $btnLog.Add_Click({ $f.Tag = "open-log"; $f.Close() })
    $f.Controls.Add($btnLog)

    $btnSair = New-Object System.Windows.Forms.Button
    $btnSair.Text = "Sair"
    $btnSair.Location = New-Object System.Drawing.Point(185, 420); $btnSair.Size = New-Object System.Drawing.Size(160, 32)
    $btnSair.Add_Click({ $f.Tag = $null; $f.Close() })
    $f.Controls.Add($btnSair)

    $f.Topmost = $true; $f.ShowDialog() | Out-Null

    # recuperar selecao do servidor
    if ($cbSrv.SelectedIndex -ge 0) {
        $srvName = ($cbSrv.SelectedItem -split '\s+-\s+')[0]
    } else { $srvName = $cfg.defaultServer }
    $srvUrl = $cfg.servers[$srvName]

    $recIdx = -1
    if ($lvRec.SelectedItems.Count -gt 0) { $recIdx = $lvRec.SelectedIndices[0] }

    return @{
        mode       = $f.Tag
        serverName = $srvName
        serverUrl  = $srvUrl
        recentIdx  = $recIdx
    }
}

# ============================================================
# RESET (modo separado)
# ============================================================
function Do-Reset($cfg) {
    $targetFolder = Pick-Folder "Escolha a pasta que voce quer RESETAR para Anthropic padrao"
    if (-not $targetFolder) { return }

    $claudeDir    = Join-Path $targetFolder ".claude"
    $settingsPath = Join-Path $claudeDir "settings.json"
    $configDir    = Join-Path $targetFolder ".claude-home"
    $envPath      = Join-Path $targetFolder ".env"
    $ollamaKeys = @('ANTHROPIC_BASE_URL','ANTHROPIC_AUTH_TOKEN','ANTHROPIC_API_KEY','ANTHROPIC_MODEL','ANTHROPIC_SMALL_FAST_MODEL','DISABLE_TELEMETRY','DISABLE_ERROR_REPORTING')
    $log = @()

    if (Test-Path $settingsPath) {
        $backupPath = "$settingsPath.bak-reset-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item $settingsPath $backupPath
        $log += "Backup: $backupPath"
        try { $c = Get-Content $settingsPath -Raw | ConvertFrom-Json -AsHashtable } catch { $c = $null }
        if ($c) {
            if ($c.ContainsKey('env') -and $c['env']) {
                foreach ($k in $ollamaKeys) { if ($c['env'].ContainsKey($k)) { $c['env'].Remove($k) | Out-Null } }
                if ($c['env'].Count -eq 0) { $c.Remove('env') | Out-Null }
            }
            if ($c.ContainsKey('model')) { $c.Remove('model') | Out-Null }
            if ($c.Count -eq 0) { Remove-Item $settingsPath -Force; $log += "settings.json removido" }
            else { $c | ConvertTo-Json -Depth 10 | Set-Content $settingsPath -Encoding UTF8; $log += "settings.json: chaves Ollama removidas" }
        }
    }

    if (Test-Path $envPath) {
        $lines = Get-Content $envPath | Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*#' }
        $keep = $lines | Where-Object { $l = $_; -not ($ollamaKeys | Where-Object { $l -match "^\s*$_\s*=" }) }
        if ($keep.Count -eq 0) { Remove-Item $envPath -Force; $log += ".env removido" }
        else { $keep | Set-Content $envPath -Encoding UTF8; $log += ".env: linhas Ollama removidas" }
    }

    if (Test-Path $configDir) {
        if (Ask-YesNo "Remover tambem '.claude-home'?" "Limpar .claude-home") {
            Remove-Item $configDir -Recurse -Force; $log += ".claude-home removido"
        }
    }

    # remover da lista de recentes
    $cfg.recentFolders = @($cfg.recentFolders | Where-Object { $_.path -ne $targetFolder })
    Save-LauncherConfig $cfg

    Show-Info ("Reset concluido:`n$targetFolder`n`n" + ($log -join "`n")) "Reset"
}

# ============================================================
# FLUXO: nova pasta (claude ou openclaude)
# ============================================================
function Do-NewFolder($cfg, $cliCommand, $serverName, $serverUrl) {
    $targetFolder = Pick-Folder "Escolha ou crie a pasta onde o $($cliCommand.ToUpper()) + Ollama vai rodar"
    if (-not $targetFolder) { return }

    $models = Get-OllamaModels $serverUrl
    if ($null -eq $models -or $models.Count -eq 0) { return }

    $defaultMain = if ($cfg.defaultModels.ContainsKey($serverName)) { $cfg.defaultModels[$serverName] } else { $null }

    $picked = Select-TwoModels $models $defaultMain $defaultMain
    if (-not $picked) { return }

    $params = $null
    if (Ask-YesNo "Configurar parametros avancados (temperature, num_ctx, seed, system)?" "Parametros") {
        $params = Edit-AdvancedParams @{}
    }

    Write-OllamaSettings $targetFolder $serverUrl $picked.main $picked.fast $params

    # atualiza modelo padrao do servidor automaticamente (ultimo usado)
    $cfg.defaultModels[$serverName] = $picked.main
    Save-LauncherConfig $cfg

    Add-RecentFolder $cfg @{
        path   = $targetFolder
        model  = $picked.main
        fast   = $picked.fast
        server = $serverName
        cli    = $cliCommand
    }
    Write-LauncherLog "new-folder" "cli=$cliCommand folder=$targetFolder main=$($picked.main) fast=$($picked.fast) server=$serverName"

    [void](Launch-CLI $cliCommand $targetFolder $serverUrl $picked.main $picked.fast)
}

# ============================================================
# FLUXO: trocar modelo (de pasta ja configurada)
# ============================================================
function Do-Switch($cfg, $serverName, $serverUrl) {
    $targetFolder = Pick-Folder "Escolha a pasta configurada cujo modelo voce quer trocar"
    if (-not $targetFolder) { return }

    $settingsPath = Join-Path $targetFolder ".claude\settings.json"
    $curMain = $null; $curFast = $null
    if (Test-Path $settingsPath) {
        try {
            $c = Get-Content $settingsPath -Raw | ConvertFrom-Json -AsHashtable
            if ($c.ContainsKey('model')) { $curMain = $c['model'] }
            if ($c.ContainsKey('env') -and $c['env'].ContainsKey('ANTHROPIC_SMALL_FAST_MODEL')) {
                $curFast = $c['env']['ANTHROPIC_SMALL_FAST_MODEL']
            }
        } catch { }
    }

    $models = Get-OllamaModels $serverUrl
    if ($null -eq $models -or $models.Count -eq 0) { return }

    $picked = Select-TwoModels $models $curMain $curFast
    if (-not $picked) { return }

    $params = $null
    if (Ask-YesNo "Editar parametros avancados tambem (temperature, num_ctx etc)?" "Parametros") {
        $params = Edit-AdvancedParams @{}
    }

    Write-OllamaSettings $targetFolder $serverUrl $picked.main $picked.fast $params
    Write-LauncherLog "switch" "folder=$targetFolder main=$curMain->$($picked.main) fast=$curFast->$($picked.fast)"

    $msg = "Modelos atualizados.`n`nPasta: $targetFolder`nPrincipal: $curMain -> $($picked.main)`nRapido: $curFast -> $($picked.fast)"
    Write-Host $msg -ForegroundColor Green

    # menu: abrir claude, openclaude ou so fechar
    $cf = New-Object System.Windows.Forms.Form
    $cf.Text = "Modelos trocados"; $cf.Size = New-Object System.Drawing.Size(480, 240)
    $cf.StartPosition = "CenterScreen"; $cf.FormBorderStyle = "FixedDialog"
    $cf.MaximizeBox = $false; $cf.MinimizeBox = $false
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $msg + "`n`nAbrir agora nessa pasta?"
    $lbl.Location = New-Object System.Drawing.Point(15, 15); $lbl.Size = New-Object System.Drawing.Size(440, 110)
    $cf.Controls.Add($lbl)
    $bC = New-Object System.Windows.Forms.Button
    $bC.Text = "Abrir CLAUDE"; $bC.Location = New-Object System.Drawing.Point(15, 140); $bC.Size = New-Object System.Drawing.Size(130, 40)
    $bC.Add_Click({ $cf.Tag = "claude"; $cf.Close() })
    $cf.Controls.Add($bC)
    $bO = New-Object System.Windows.Forms.Button
    $bO.Text = "Abrir OPENCLAUDE"; $bO.Location = New-Object System.Drawing.Point(155, 140); $bO.Size = New-Object System.Drawing.Size(160, 40)
    $bO.Add_Click({ $cf.Tag = "openclaude"; $cf.Close() })
    $cf.Controls.Add($bO)
    $bN = New-Object System.Windows.Forms.Button
    $bN.Text = "Fechar"; $bN.Location = New-Object System.Drawing.Point(325, 140); $bN.Size = New-Object System.Drawing.Size(130, 40)
    $bN.Add_Click({ $cf.Tag = $null; $cf.Close() })
    $cf.Controls.Add($bN)
    $cf.Topmost = $true; $cf.ShowDialog() | Out-Null

    if ($cf.Tag) {
        Add-RecentFolder $cfg @{
            path = $targetFolder; model = $picked.main; fast = $picked.fast; server = $serverName; cli = $cf.Tag
        }
        [void](Launch-CLI $cf.Tag $targetFolder $serverUrl $picked.main $picked.fast)
    } else {
        Add-RecentFolder $cfg @{
            path = $targetFolder; model = $picked.main; fast = $picked.fast; server = $serverName; cli = "claude"
        }
    }
}

# ============================================================
# FLUXO: reabrir pasta recente
# ============================================================
function Do-Recent($cfg, $idx, $serverUrl) {
    $r = $cfg.recentFolders[$idx]
    if (-not (Test-Path $r.path)) {
        if (Ask-YesNo "Pasta nao existe mais: $($r.path)`n`nRemover da lista?" "Pasta ausente") {
            $cfg.recentFolders = @($cfg.recentFolders | Where-Object { $_.path -ne $r.path })
            Save-LauncherConfig $cfg
        }
        return
    }
    Write-OllamaSettings $r.path $serverUrl $r.model $r.fast $null
    Add-RecentFolder $cfg @{ path = $r.path; model = $r.model; fast = $r.fast; server = $r.server; cli = $r.cli }
    Write-LauncherLog "recent-reopen" "cli=$($r.cli) folder=$($r.path) main=$($r.model)"
    [void](Launch-CLI $r.cli $r.path $serverUrl $r.model $r.fast)
}

# ============================================================
# MAIN LOOP
# ============================================================
$cfg = Get-LauncherConfig

# se -OllamaHost foi passado, sobrepoe e adiciona como servidor "cli-override"
if ($OllamaHost) {
    $cfg.servers["cli-override"] = $OllamaHost
    $cfg.defaultServer = "cli-override"
}

while ($true) {
    $result = Show-MainMenu $cfg
    if (-not $result.mode) { break }

    $serverName = $result.serverName
    $serverUrl  = $result.serverUrl

    switch -Regex ($result.mode) {
        "^new:(claude|openclaude)$" {
            $cli = ($result.mode -split ':')[1]
            Do-NewFolder $cfg $cli $serverName $serverUrl
        }
        "^switch$"          { Do-Switch $cfg $serverName $serverUrl }
        "^reset$"           { Do-Reset $cfg }
        "^manage-servers$"  { $cfg = Manage-Servers $cfg }
        "^manage-models$"   { Manage-Models $serverUrl }
        "^recent$" {
            if ($result.recentIdx -ge 0) { Do-Recent $cfg $result.recentIdx $serverUrl }
            $cfg = Get-LauncherConfig
        }
        "^recent-del$" {
            if ($result.recentIdx -ge 0) {
                $p = $cfg.recentFolders[$result.recentIdx].path
                $cfg.recentFolders = @($cfg.recentFolders | Where-Object { $_.path -ne $p })
                Save-LauncherConfig $cfg
            }
        }
        "^open-log$" {
            if (Test-Path $script:LogPath) { Start-Process notepad.exe $script:LogPath }
            else { Show-Info "Ainda nao ha log gerado." "Log" }
        }
        "^set-default-model$" {
            $models = Get-OllamaModels $serverUrl
            if ($models -and $models.Count -gt 0) {
                $cur = if ($cfg.defaultModels.ContainsKey($serverName)) { $cfg.defaultModels[$serverName] } else { $null }
                $picked = Select-Model $models "Modelo padrao do servidor '$serverName'" "Selecione o modelo que sera pre-selecionado por padrao neste servidor:" "Definir"
                if ($picked) {
                    $cfg.defaultModels[$serverName] = $picked
                    Save-LauncherConfig $cfg
                    Show-Info "Modelo padrao de '$serverName' definido como: $picked" "Padrao atualizado"
                }
            }
        }
    }
}

Write-Host "Launcher encerrado." -ForegroundColor DarkGray
