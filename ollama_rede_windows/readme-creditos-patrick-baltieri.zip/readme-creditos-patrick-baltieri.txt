README - Claude Ollama Launcher

Código original: Patrick Baltieri
Instagram: https://www.instagram.com/patrickbaltieri/

Observação:
Este material foi compartilhado com o objetivo de facilitar testes e estudos envolvendo Claude Code, Ollama e uso de modelos em rede local.

Créditos:
A criação original do código é de Patrick Baltieri. Qualquer adaptação, explicação ou demonstração feita posteriormente deve manter os devidos créditos ao autor original.

Aviso importante:
Este projeto deve ser usado com cuidado, preferencialmente em ambiente de teste. Antes de executar scripts baixados ou compartilhados por terceiros, revise o conteúdo dos arquivos e evite rodar como administrador sem necessidade.
