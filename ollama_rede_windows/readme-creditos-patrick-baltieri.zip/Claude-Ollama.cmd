@echo off
title Claude + Ollama Launcher

where pwsh >nul 2>nul
if %ERRORLEVEL%==0 (
    pwsh.exe -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0claude-ollama.ps1"
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0claude-ollama.ps1"
)
