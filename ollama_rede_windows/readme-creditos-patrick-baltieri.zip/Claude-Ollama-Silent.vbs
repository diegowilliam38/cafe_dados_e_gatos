' Launcher silencioso - abre a UI sem mostrar console do PowerShell.
' As janelas do Claude (spawned pelo launcher) continuam visiveis normalmente.

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1Path   = scriptDir & "\claude-ollama.ps1"

' tenta pwsh (PowerShell 7) primeiro; se nao existir, usa powershell 5.1
psExe = "pwsh.exe"
Set oExec = Nothing
On Error Resume Next
sh.Run "pwsh -Version", 0, True
If Err.Number <> 0 Then psExe = "powershell.exe"
Err.Clear
On Error Goto 0

cmdLine = psExe & " -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1Path & """"

' segundo argumento 0 = janela oculta; terceiro = nao esperar
sh.Run cmdLine, 0, False
