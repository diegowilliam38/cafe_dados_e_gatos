# Versao Publica

Versao simples para o publico dos videos no YouTube.

Leitura rapida:

- `COMECE_AQUI.md`
- `CONFIG_GITHUB.md`
- `CHECKLIST_DE_ENTREGA.md`

Entrega o nucleo da automacao:

- coleta do feed affiliate
- catalogo com todas as categorias
- destaques de mais vendidos
- destaques de maior desconto
- workflow de GitHub Actions
- saida propria em `output/catalog/`

## O que este pacote gera

- `categories.json`: lista e resumo de categorias
- `categories/<slug>.json`: pagina de cada categoria
- `highlights/best-sellers.json`: mais vendidos globais
- `highlights/top-discounts.json`: maiores descontos globais
- `manifest.json`: resumo da geracao

Destino padrao da saida:

```text
output/catalog/
```

## Setup local

```bash
cd kit_shopee_todas_categorias/versao_publica
cp .env.example .env
cp config/catalog_config.example.json config/catalog_config.json
pip3 install -r requirements.txt
python3 scripts/build_catalog.py --verbose
```

## Execucao no GitHub

O pacote pode rodar sob demanda pelo botao `Actions > Run workflow`.
Se a pessoa quiser agendar, basta editar o `cron` em `.github/workflows/update-catalog.yml`
e `.github/workflows/update-banners.yml`.
Se os secrets de FTP estiverem preenchidos, o mesmo workflow publica o resultado no servidor da pessoa.

## GitHub Secrets necessarios

- `SHOPEE_APP_ID`
- `SHOPEE_SECRET`

`SHOPEE_API_URL` e opcional neste kit. O script ja usa por padrao:

```text
https://open-api.affiliate.shopee.com.br/graphql
```

So crie esse secret se quiser sobrescrever a URL padrao.

Se quiser publicar por FTP depois, adicione um passo proprio no workflow com:

- `FTP_HOST`
- `FTP_USERNAME`
- `FTP_PASSWORD`
- `FTP_REMOTE_DIR` opcional, se quiser sobrescrever o destino padrao

Veja tambem `CONFIG_GITHUB.md` para o passo a passo de como isso entra no repositorio da pessoa.

## Configuracao

Edite `config/catalog_config.json`:

- `limit_per_category`: quantos produtos cada categoria publica
- `highlights_limit`: quantos itens entram em mais vendidos / descontos
- `min_discount_pct`: filtro minimo de desconto
- `min_price`: evita produtos lixo com preco irreal
- `include_categories`: lista opcional de slugs para whitelist
- `exclude_categories`: lista opcional de slugs para blacklist

## Observacoes

- o script prefere `FULL` e so cai para `DELTA` se necessario
- o catalogo e refeito do zero a cada execucao
- o schema foi pensado para um site generico, nao para nicho manual
- a versao publica nao depende do site premium para funcionar; ela pode
  ser distribuida so como automacao + JSON
- o workflow pode ser manual ou agendado; o agendamento fica no `cron` do YAML
- se os secrets de FTP existirem, o workflow publica os JSONs no site da pessoa

## Se quiser plugar na versao de assinantes

Se voce quiser usar a automacao publica como fonte do site premium, copie o
conteudo de:

```text
versao_publica/output/catalog/
```

para:

```text
../versao_assinantes/site/data/catalog/
```

Isso pode ser feito manualmente, por script, por deploy ou dentro do workflow.
