#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from contextlib import contextmanager
from ftplib import FTP
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = THIS_DIR.parent
sys.path.insert(0, str(PACKAGE_ROOT))

DEFAULT_CONFIG = PACKAGE_ROOT / "config" / "catalog_config.json"
DEFAULT_LOCAL = PACKAGE_ROOT / "output" / "catalog"


def load_config(path: Path) -> dict:
    if not path.is_file():
        fallback = PACKAGE_ROOT / "config" / "catalog_config.example.json"
        if fallback.is_file():
            path = fallback
        else:
            return {}
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


@contextmanager
def ftp_cwd(ftp: FTP, path: str):
    previous = ftp.pwd()
    target = path.strip().strip("/")
    if target:
        for part in target.split("/"):
            try:
                ftp.cwd(part)
            except Exception:
                ftp.mkd(part)
                ftp.cwd(part)
    try:
        yield
    finally:
        ftp.cwd(previous)


def upload_tree(ftp: FTP, local_root: Path, remote_root: str) -> int:
    uploaded = 0
    local_root = local_root.resolve()
    target_root = remote_root.strip().strip("/")
    with ftp_cwd(ftp, target_root):
        for path in sorted(local_root.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(local_root)
            remote_dir = relative.parent.as_posix().strip(".")
            with ftp_cwd(ftp, remote_dir):
                with path.open("rb") as fh:
                    ftp.storbinary(f"STOR {relative.name}", fh)
                uploaded += 1
    return uploaded


def main() -> int:
    parser = argparse.ArgumentParser(description="Publica o catalogo gerado via FTP.")
    parser.add_argument("--local", type=Path, default=DEFAULT_LOCAL)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--remote-dir", type=str, default="")
    args = parser.parse_args()

    host = os.environ.get("FTP_HOST", "").strip()
    username = os.environ.get("FTP_USERNAME", "").strip()
    password = os.environ.get("FTP_PASSWORD", "").strip()

    if not host or not username or not password:
        print("[skip] FTP_HOST/FTP_USERNAME/FTP_PASSWORD nao configurados; deploy ignorado.")
        return 0

    config = load_config(args.config)
    remote_dir = args.remote_dir.strip() or os.environ.get("FTP_REMOTE_DIR", "").strip()
    if not remote_dir:
        remote_dir = str(config.get("deploy", {}).get("remote_dir", "/public_html/data/catalog")).strip()
    if not remote_dir:
        remote_dir = "/public_html/data/catalog"

    local_root = args.local
    if not local_root.is_dir():
        print(f"[erro] pasta local nao encontrada: {local_root}", file=sys.stderr)
        return 1

    ftp = FTP(host, timeout=60)
    try:
        ftp.login(username, password)
        ftp.set_pasv(True)
        uploaded = upload_tree(ftp, local_root, remote_dir)
        print(f"OK: publicado {uploaded} arquivos em {remote_dir}")
    finally:
        try:
            ftp.quit()
        except Exception:
            ftp.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
