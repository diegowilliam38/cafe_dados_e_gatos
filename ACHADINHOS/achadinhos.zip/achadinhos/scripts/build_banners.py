#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

THIS_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = THIS_DIR.parent
sys.path.insert(0, str(PACKAGE_ROOT))

from lib.shopee_client import ShopeeApiError, ShopeeClient

TIMEZONE = "America/Sao_Paulo"
DEFAULT_OUTPUT = PACKAGE_ROOT / "output" / "catalog" / "banners.json"
GENERAL_PAGES = 4
SEARCH_KEYWORDS = (
    "tecnologia",
    "eletronicos",
    "casa",
    "beleza",
    "moda",
    "pets",
    "automotivo",
    "papelaria",
)
SECTION_KEYWORDS: dict[str, tuple[str, ...]] = {
    "hero": ("tecnologia", "eletronicos", "casa", "beleza"),
    "tech": ("tecnologia", "computador", "pc", "gamer", "celular", "audio"),
    "casa": ("casa", "cozinha", "decoracao", "organizacao"),
    "beleza": ("beleza", "skincare", "cabelo", "maquiagem"),
    "moda": ("moda", "feminina", "masculina", "tenis", "bolsa"),
    "pets": ("pet", "pets", "gato", "cachorro"),
}


def normalize(text: str) -> str:
    return (text or "").lower().strip()


def has_any(text: str, keywords: tuple[str, ...]) -> bool:
    text = normalize(text)
    return any(keyword in text for keyword in keywords)


def fetch_general_offers(client: ShopeeClient, page: int, limit: int) -> list[dict]:
    query = """
    query shopeeOfferV2($page: Int!, $limit: Int!, $sortType: Int!) {
      shopeeOfferV2(page: $page, limit: $limit, sortType: $sortType) {
        nodes {
          offerName
          offerLink
          originalLink
          imageUrl
          commissionRate
          offerType
          categoryId
          collectionId
          periodStartTime
          periodEndTime
        }
      }
    }
    """
    data = client._post(query, {"page": page, "limit": limit, "sortType": 1})
    nodes = (data.get("shopeeOfferV2") or {}).get("nodes") or []
    return [node for node in nodes if isinstance(node, dict)]


def fetch_keyword_offers(client: ShopeeClient, keyword: str, limit: int) -> list[dict]:
    query = """
    query shopeeOfferV2($keyword: String!, $page: Int!, $limit: Int!, $sortType: Int!) {
      shopeeOfferV2(keyword: $keyword, page: $page, limit: $limit, sortType: $sortType) {
        nodes {
          offerName
          offerLink
          originalLink
          imageUrl
          commissionRate
          offerType
          categoryId
          collectionId
          periodStartTime
          periodEndTime
        }
      }
    }
    """
    data = client._post(query, {"keyword": keyword, "page": 1, "limit": limit, "sortType": 1})
    nodes = (data.get("shopeeOfferV2") or {}).get("nodes") or []
    return [node for node in nodes if isinstance(node, dict)]


def clean_offer(node: dict) -> dict | None:
    title = str(node.get("offerName") or "").strip()
    image = str(node.get("imageUrl") or "").strip()
    url = str(node.get("offerLink") or "").strip()
    if not title or not image or not url:
        return None
    return {
        "title": title,
        "image": image,
        "url": url,
        "commission_rate": str(node.get("commissionRate") or "").strip(),
        "offer_type": node.get("offerType"),
        "category_id": node.get("categoryId"),
        "collection_id": node.get("collectionId"),
        "period_start_time": node.get("periodStartTime"),
        "period_end_time": node.get("periodEndTime"),
    }


def assign_sections(banners: list[dict]) -> dict[str, list[dict]]:
    by_section: dict[str, list[dict]] = {name: [] for name in SECTION_KEYWORDS}
    for section, keywords in SECTION_KEYWORDS.items():
        used: set[str] = set()
        for banner in banners:
            if banner["url"] in used:
                continue
            if has_any(banner["title"], keywords):
                by_section[section].append(banner)
                used.add(banner["url"])
            if len(by_section[section]) >= 2:
                break
    return by_section


def main() -> int:
    parser = argparse.ArgumentParser(description="Gera banners/campanhas Shopee para o kit.")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    env_path = PACKAGE_ROOT / ".env"
    if env_path.is_file():
        load_dotenv(env_path, override=False)

    app_id = os.environ.get("SHOPEE_APP_ID", "").strip()
    app_secret = os.environ.get("SHOPEE_SECRET", "").strip()
    api_url = os.environ.get("SHOPEE_API_URL", "").strip() or "https://open-api.affiliate.shopee.com.br/graphql"
    if not app_id or not app_secret:
        print("[erro] preencha SHOPEE_APP_ID e SHOPEE_SECRET", file=sys.stderr)
        return 1

    client = ShopeeClient(app_id=app_id, app_secret=app_secret, api_url=api_url)
    seen: set[str] = set()
    banners: list[dict] = []

    for page in range(1, GENERAL_PAGES + 1):
        try:
            nodes = fetch_general_offers(client, page, args.limit)
        except ShopeeApiError as exc:
            print(f"[aviso] geral page={page} falhou: {exc}", file=sys.stderr)
            break
        for node in nodes:
            banner = clean_offer(node)
            if not banner or banner["url"] in seen:
                continue
            seen.add(banner["url"])
            banners.append(banner)

    for keyword in SEARCH_KEYWORDS:
        try:
            nodes = fetch_keyword_offers(client, keyword, args.limit)
        except ShopeeApiError as exc:
            print(f"[aviso] keyword={keyword!r} falhou: {exc}", file=sys.stderr)
            continue
        for node in nodes:
            banner = clean_offer(node)
            if not banner or banner["url"] in seen:
                continue
            seen.add(banner["url"])
            banners.append(banner)

    payload = {
        "generated_at": datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"),
        "source": "shopeeOfferV2",
        "keywords": list(SEARCH_KEYWORDS),
        "banners": banners,
        "by_section": assign_sections(banners),
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"OK: gravado {args.output} ({len(banners)} banners)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
