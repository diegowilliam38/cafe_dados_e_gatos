# Comece Aqui

Esta e a versao simples do kit.

## O que voce precisa

- conta no GitHub
- `SHOPEE_APP_ID`
- `SHOPEE_SECRET`

## Passo a passo

1. crie um repositorio novo
2. coloque os arquivos desta pasta na raiz do repo
3. no GitHub, abra:

```text
Settings > Secrets and variables > Actions
```

4. crie os secrets:
   - `SHOPEE_APP_ID`
   - `SHOPEE_SECRET`
5. copie:

```text
config/catalog_config.example.json
```

para:

```text
config/catalog_config.json
```

6. rode o workflow `Atualizar catalogo completo Shopee` manualmente em `Actions`
7. baixe o artefato `catalogo-shopee`

## URL da API

O kit ja usa por padrao:

```text
https://open-api.affiliate.shopee.com.br/graphql
```

So altere isso se a Shopee pedir outro endpoint.

## Ler depois

- `README.md`
- `CONFIG_GITHUB.md`
