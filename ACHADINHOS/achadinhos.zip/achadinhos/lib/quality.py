"""Pontuacao editorial e badges para produtos da loja."""

from __future__ import annotations

import math
import re
import unicodedata
from typing import Any


def normalize_text(text: str) -> str:
    if not text:
        return ""
    decomposed = unicodedata.normalize("NFKD", text)
    no_accents = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return no_accents.lower().strip()


def to_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def to_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except (TypeError, ValueError):
        return default


LOW_QUALITY_TERMS: tuple[str, ...] = (
    "generico",
    "sortido",
    "aleatorio",
    "surpresa",
    "sem marca",
    "segunda linha",
    "avaria",
    "defeito",
    "usado",
    "reembalado",
)


TITLE_NOISE_TERMS: tuple[str, ...] = (
    "queima de estoque",
    "imperdivel",
    "promoção",
    "promocao",
    "atacado",
    "liquida",
    "liquidacao",
)


def quality_flags(product: dict[str, Any]) -> list[str]:
    """Retorna sinais de risco/baixa qualidade para auditoria local."""
    title = normalize_text(str(product.get("title") or ""))
    rating = to_float(product.get("rating"))
    sales = to_int(product.get("sales_count"))
    discount = to_int(product.get("discount_pct"))
    price = to_float(product.get("price_current"))

    flags: list[str] = []
    if price <= 0:
        flags.append("preco_invalido")
    if rating <= 0:
        flags.append("sem_rating")
    elif rating < 4.2:
        flags.append("rating_baixo")
    if sales <= 0:
        flags.append("sem_vendas")
    if discount <= 0:
        flags.append("sem_desconto")
    if len(title) < 18:
        flags.append("titulo_curto")
    if len(title) > 150:
        flags.append("titulo_longo")
    if any(term in title for term in LOW_QUALITY_TERMS):
        flags.append("termo_baixa_qualidade")
    if sum(1 for term in TITLE_NOISE_TERMS if term in title) >= 2:
        flags.append("titulo_promocional_demais")
    if re.search(r"\b[0-9]{4,}\s*pcs\b", title):
        flags.append("quantidade_suspeita")
    return flags


def product_score(product: dict[str, Any]) -> float:
    """Score editorial: desconto + confianca + popularidade + pequenas penalidades."""
    discount = max(0, min(95, to_int(product.get("discount_pct"))))
    rating = max(0.0, min(5.0, to_float(product.get("rating"))))
    sales = max(0, to_int(product.get("sales_count")))

    score = 0.0
    score += discount * 1.7
    if rating > 0:
        score += rating * 10.0
    if sales > 0:
        score += math.log10(sales + 1) * 12.0

    # Bonus para produtos que combinam desconto forte e confianca minima.
    if discount >= 40 and rating >= 4.6:
        score += 12
    elif discount >= 25 and rating >= 4.5:
        score += 6

    flags = quality_flags(product)
    penalties = {
        "preco_invalido": 100,
        "sem_rating": 12,
        "rating_baixo": 30,
        "sem_vendas": 4,
        "sem_desconto": 18,
        "titulo_curto": 5,
        "titulo_longo": 4,
        "termo_baixa_qualidade": 18,
        "titulo_promocional_demais": 6,
        "quantidade_suspeita": 8,
    }
    score -= sum(penalties.get(flag, 0) for flag in flags)
    return round(max(0.0, score), 2)


def score_reasons(product: dict[str, Any]) -> list[str]:
    discount = to_int(product.get("discount_pct"))
    rating = to_float(product.get("rating"))
    sales = to_int(product.get("sales_count"))
    reasons: list[str] = []
    if discount >= 40:
        reasons.append("desconto_alto")
    elif discount >= 20:
        reasons.append("bom_desconto")
    if rating >= 4.7:
        reasons.append("rating_alto")
    elif rating >= 4.4:
        reasons.append("rating_bom")
    if sales >= 1000:
        reasons.append("muitas_vendas")
    elif sales >= 100:
        reasons.append("vendas_relevantes")
    return reasons


def assign_badges(product: dict[str, Any]) -> list[str]:
    discount = to_int(product.get("discount_pct"))
    rating = to_float(product.get("rating"))
    sales = to_int(product.get("sales_count"))
    score = to_float(product.get("score"))
    badges: list[str] = []

    if score >= 100:
        badges.append("achado_confiavel")
    if discount >= 50:
        badges.append("melhor_desconto")
    elif discount >= 35:
        badges.append("oferta_quente")
    if rating >= 4.7:
        badges.append("bom_rating")
    if sales >= 1000:
        badges.append("mais_vendido")
    return badges[:4]


def enrich_product_quality(product: dict[str, Any]) -> dict[str, Any]:
    """Adiciona score, motivos, badges e flags sem alterar campos de origem."""
    product["quality_flags"] = quality_flags(product)
    product["score"] = product_score(product)
    product["score_reasons"] = score_reasons(product)
    product["badges"] = assign_badges(product)
    return product
