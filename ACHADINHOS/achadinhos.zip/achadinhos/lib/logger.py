"""Logger simples em arquivo para os scripts de atualização.

Mantém o mesmo padrão usado em /home/denise/Documents/shopee/claude_code/scripts
(classe `Logger` com `add(key, value)` e `save()`), só que com um helper
opcional para logar a duração de uma etapa em ms.
"""

from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path
from typing import Any


class Logger:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lines: list[str] = []
        self._start: float | None = None

    def add(self, key: str, value: Any) -> None:
        self.lines.append(f"[{key}] {value}")

    def step(self, name: str) -> "_Step":
        return _Step(self, name)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as f:
            f.write("\n".join(self.lines))
            if self.lines:
                f.write("\n")


def make_logger(logs_dir: Path) -> tuple[Logger, Path]:
    """Cria um Logger com nome de arquivo baseado na data/hora local."""
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    filename = f"atualizar_{timestamp}.log"
    return Logger(logs_dir / filename), logs_dir / filename


class _Step:
    """Context manager que mede duração de uma etapa e loga em ms."""

    def __init__(self, logger: Logger, name: str) -> None:
        self.logger = logger
        self.name = name
        self._start: float = 0.0

    def __enter__(self) -> "_Step":
        self._start = time.perf_counter()
        self.logger.add(f"start:{self.name}", datetime.now().isoformat(timespec="seconds"))
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        elapsed_ms = int((time.perf_counter() - self._start) * 1000)
        status = "ok" if exc_type is None else f"error:{exc_type.__name__}"
        self.logger.add(f"end:{self.name}", f"{status} elapsed_ms={elapsed_ms}")
