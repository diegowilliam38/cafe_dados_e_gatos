"""Cliente da Product Feed API da Shopee Affiliate.

Workflow:
  1. listItemFeeds(feedMode) → descobre o datafeedId (FULL ou DELTA)
  2. getItemFeedData(datafeedId, offset, limit) → pagina até o fim
  3. Cada row[].columns é uma STRING JSON que precisa de json.loads()
  4. Filtra/normalize e grava no JSON da loja

Os links já vêm no formato curto de afiliado (`product_short link`).
"""

from __future__ import annotations

import json
from typing import Any, Iterator

from .shopee_client import ShopeeClient, ShopeeApiError


# Feeds preferidos, em ordem de prioridade.
# 1) "Shopee Oficial BR" (100k FULL, 165k DELTA) — inclui importados. Decisão Denise 2026-06-06.
# 2) "Shopee Brasil" (10k FULL) — fallback caso o Oficial BR não esteja disponível.
PREFERRED_FEED_NAMES = ("Shopee Oficial BR", "Shopee Brasil")
MAX_LIMIT_PER_PAGE = 500


def list_feeds(client: ShopeeClient, feed_mode: str = "FULL") -> list[dict[str, Any]]:
    """Lista os feeds disponíveis. feed_mode ∈ {FULL, DELTA}."""
    query = (
        "{ listItemFeeds(feedMode: " + feed_mode + ") { feeds "
        "{ datafeedId datafeedName referenceId description totalCount date feedMode } } }"
    )
    data = client._post(query, {})  # noqa: SLF001 — acesso controlado
    conn = data.get("listItemFeeds") or {}
    return conn.get("feeds") or []


def find_preferred_feed(client: ShopeeClient, feed_mode: str = "FULL") -> dict[str, Any] | None:
    """Acha o feed preferido (Oficial BR 100k; fallback Shopee Brasil 10k)."""
    feeds = list_feeds(client, feed_mode)
    if not feeds:
        return None
    for name in PREFERRED_FEED_NAMES:
        for f in feeds:
            if name.lower() in (f.get("datafeedName") or "").lower():
                return f
    return feeds[0]


def iter_feed_rows(client: ShopeeClient, datafeed_id: str, page_size: int = MAX_LIMIT_PER_PAGE) -> Iterator[dict[str, Any]]:
    """Itera TODAS as rows de um feed, paginando automaticamente."""
    offset = 0
    while True:
        query = (
            '{ getItemFeedData(datafeedId: "'
            + datafeed_id
            + '", offset: '
            + str(offset)
            + ", limit: "
            + str(page_size)
            + ") { rows { columns updateType } pageInfo { offset limit totalCount hasMore } } }"
        )
        try:
            data = client._post(query, {})  # noqa: SLF001
        except ShopeeApiError as exc:
            raise ShopeeApiError(f"Falha ao baixar feed {datafeed_id} (offset={offset}): {exc}") from exc

        payload = data.get("getItemFeedData") or {}
        rows = payload.get("rows") or []
        for row in rows:
            yield row
        page_info = payload.get("pageInfo") or {}
        if not page_info.get("hasMore"):
            return
        offset = (page_info.get("offset") or offset) + page_info.get("limit", page_size)


def parse_row_columns(row: dict[str, Any]) -> dict[str, Any] | None:
    """Faz json.loads() no `columns` e retorna dict, ou None se inválido."""
    raw = row.get("columns")
    if not isinstance(raw, str) or not raw.strip():
        return None
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return None
    return data if isinstance(data, dict) else None


def to_number(value: Any, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def to_int(value: Any, default: int = 0) -> int:
    if value is None or value == "":
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def normalize_product(cols: dict[str, Any]) -> dict[str, Any] | None:
    """Converte o dict cru do feed no shape consumido pela página PHP.

    Shape de saída (loja_achadinhos/data/produtos.json):
        id, title, image, category, price_current, price_original,
        discount_pct, rating, sales_count, url, seller

    A categoria (racao, acessorios, etc.) NÃO é definida aqui — quem
    faz isso é o classificador em lib.categories.classify(), chamado
    pelo atualizar.py. Aqui devolvemos só os dados crus + "category_raw"
    (que vem do global_category1) para o classificador olhar.
    """
    item_id = (cols.get("itemid") or "").strip()
    title = (cols.get("title") or "").strip()
    image = (cols.get("image_link") or "").strip()
    # Atenção: a chave JSON vem COM espaço — "product_short link"
    url = (cols.get("product_short link") or "").strip()
    if not url:
        url = (cols.get("product_link") or "").strip()
    if not (item_id and title and image and url):
        return None

    price_current = to_number(cols.get("sale_price") or cols.get("price"))
    price_original = to_number(cols.get("price"))
    if price_original and price_original < price_current:
        # Alguns produtos têm sale_price > price; nesse caso o desconto é 0
        price_original = None
    if price_original and price_original == price_current:
        price_original = None

    discount = to_int(cols.get("discount_percentage"))
    if price_original and price_current and not discount:
        diff = price_original - price_current
        if diff > 0 and price_original > 0:
            discount = int(round(diff / price_original * 100))

    return {
        "id": item_id,
        "title": title,
        "image": image,
        "category": None,  # preenchido pelo classificador
        "price_current": price_current,
        "price_original": price_original or None,
        "discount_pct": discount,
        "rating": to_number(cols.get("item_rating")),
        "sales_count": None,  # feed não expõe; manter None
        "url": url,
        "seller": (cols.get("shop_name") or cols.get("global_category1") or "").strip() or None,
        "source_detail": "feed_affiliate",
        "_category_raw": (cols.get("global_category1") or "").strip(),
        "_category2_raw": (cols.get("global_category2") or "").strip(),
    }
