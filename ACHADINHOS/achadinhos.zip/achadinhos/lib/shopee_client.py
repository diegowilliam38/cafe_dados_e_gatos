"""Cliente GraphQL para a API de Afiliados da Shopee (Open API).

Endpoint: https://open-api.affiliate.shopee.com.br/graphql (Brasil).

A autenticação é feita via header `Authorization` no formato:
    SHA256 Credential=<APP_ID>, Timestamp=<unix_ts>, Signature=<sha256>

Onde:
    Signature = sha256( APP_SECRET + str(TIMESTAMP) + raw_body )

O `raw_body` é exatamente o JSON serializado que vai no POST (sem reformatar).
Para evitar pegadinhas, montamos o payload uma única vez e reusamos a string
tanto no SHA256 quanto no `requests.post(... data=raw)`.

Queries usadas (valores default funcionam para a curadoria do nicho):
  - productOfferV2: pega ofertas ativas. sortType=2 = maior desconto.
  - searchProduct : busca por keyword (usado como fallback / expansão).

A função pública `fetch_curated()` cuida de paginação, retry e seleção
inicial de produtos que tenham desconto > 0 (a vitrine só mostra promoções).
"""

from __future__ import annotations

import hashlib
import json
import time
from typing import Any, Iterable

import requests


class ShopeeApiError(RuntimeError):
    """Erro retornado pela API da Shopee (HTTP 200 com errors[] não vazio)."""


class ShopeeClient:
    def __init__(
        self,
        app_id: str,
        app_secret: str,
        api_url: str = "https://open-api.affiliate.shopee.com.br/graphql",
        timeout: float = 20.0,
        max_retries: int = 3,
        backoff_seconds: float = 1.5,
    ) -> None:
        if not app_id or not app_secret:
            raise ValueError("SHOPEE_APP_ID e SHOPEE_SECRET são obrigatórios.")
        self.app_id = app_id
        self.app_secret = app_secret
        self.api_url = api_url
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_seconds = backoff_seconds

    # --- auth ----------------------------------------------------------------

    def _sign(self, timestamp: int, raw_body: str) -> str:
        """
        Fórmula da doc oficial Shopee Affiliate Open API:
            signature = SHA256(AppId + Timestamp + Payload + Secret)
        """
        factor = f"{self.app_id}{timestamp}{raw_body}{self.app_secret}".encode("utf-8")
        return hashlib.sha256(factor).hexdigest()

    def _auth_headers(self, raw_body: str) -> dict[str, str]:
        timestamp = int(time.time())
        signature = self._sign(timestamp, raw_body)
        return {
            "Content-Type": "application/json",
            "Authorization": f"SHA256 Credential={self.app_id}, Timestamp={timestamp}, Signature={signature}",
        }

    # --- transporte ----------------------------------------------------------

    def _post(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        body_obj = {"query": query, "variables": variables}
        # IMPORTANTE: o JSON usado na assinatura precisa ser byte-equivalente
        # ao que vai no POST. Usamos json.dumps(..., separators=(",", ":"))
        # (formato compacto, sem espaços) e o requests reenvia exatamente isso.
        raw_body = json.dumps(body_obj, separators=(",", ":"))
        headers = self._auth_headers(raw_body)

        last_exc: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                resp = requests.post(
                    self.api_url,
                    headers=headers,
                    data=raw_body.encode("utf-8"),
                    timeout=self.timeout,
                )
            except requests.exceptions.RequestException as exc:
                last_exc = exc
                if attempt >= self.max_retries:
                    raise ShopeeApiError(f"Falha de rede após {attempt} tentativas: {exc}") from exc
                time.sleep(self.backoff_seconds * attempt)
                continue

            if resp.status_code >= 500:
                last_exc = ShopeeApiError(f"HTTP {resp.status_code} da API: {resp.text[:200]}")
                if attempt >= self.max_retries:
                    raise last_exc
                time.sleep(self.backoff_seconds * attempt)
                continue

            if resp.status_code != 200:
                raise ShopeeApiError(
                    f"HTTP {resp.status_code} inesperado: {resp.text[:200]}"
                )

            try:
                data = resp.json()
            except ValueError as exc:
                raise ShopeeApiError(f"Resposta não é JSON válido: {resp.text[:200]}") from exc

            if data.get("errors"):
                raise ShopeeApiError(f"API retornou errors: {data['errors']}")

            return data.get("data") or {}

        # unreachable, mas mantém o type checker feliz
        raise ShopeeApiError(str(last_exc) if last_exc else "Falha desconhecida")

    # --- queries -------------------------------------------------------------

    def fetch_offer_page(self, page: int, page_size: int = 50) -> list[dict[str, Any]]:
        """productOfferV2 — ofertas ativas, ordenadas por maior desconto (sortType=2).

        IMPORTANTE (2026-06-08): o campo de vendas é `sales` (não `salesCount`).
        Bug antigo: esse arquivo pedia `salesCount` (nome do feed Affiliate),
        mas `productOfferV2` retorna `sales`. Por isso TODOS os produtos
        vinham com sales_count=None. Fix em 2026-06-08.
        """
        query = """
        query productOfferV2($page: Int!, $limit: Int!) {
          productOfferV2(page: $page, limit: $limit, sortType: 2) {
            nodes {
              productId
              productName
              productImage
              offerLink
              priceMin
              priceMax
              discountPct
              ratingStar
              sales
              shopName
              categoryName
              commissionRate
            }
            pageInfo { page size total }
          }
        }
        """
        data = self._post(query, {"page": page, "limit": page_size})
        nodes = (data.get("productOfferV2") or {}).get("nodes") or []
        return [n for n in nodes if isinstance(n, dict)]

    def search_keyword(self, keyword: str, page: int = 1, page_size: int = 50) -> list[dict[str, Any]]:
        """searchProduct — busca por palavra-chave."""
        query = """
        query searchProduct($keyword: String!, $page: Int!, $limit: Int!) {
          searchProduct(keyword: $keyword, page: $page, limit: $limit) {
            nodes {
              productId
              productName
              productImage
              offerLink
              priceMin
              priceMax
              discountPct
              ratingStar
              sales
              shopName
              categoryName
              commissionRate
            }
            pageInfo { page size total }
          }
        }
        """
        data = self._post(query, {"keyword": keyword, "page": page, "limit": page_size})
        nodes = (data.get("searchProduct") or {}).get("nodes") or []
        return [n for n in nodes if isinstance(n, dict)]

    # --- alto nível ----------------------------------------------------------

    def fetch_curated(self, max_pages: int = 5, page_size: int = 50) -> list[dict[str, Any]]:
        """Busca ofertas ativas paginando até `max_pages` ou resposta vazia.

        Filtra produtos sem desconto (>0%) e deduplica por `productId`.
        """
        seen: dict[str, dict[str, Any]] = {}
        for page in range(1, max_pages + 1):
            try:
                nodes = self.fetch_offer_page(page=page, page_size=page_size)
            except ShopeeApiError as exc:
                # propaga para o caller tratar
                raise
            if not nodes:
                break
            for node in nodes:
                pid = str(node.get("productId") or "")
                if not pid or pid in seen:
                    continue
                seen[pid] = node
            if len(nodes) < page_size:
                # Página parcial = última página disponível
                break
        return list(seen.values())


# --- normalização ------------------------------------------------------------


def normalize_product(node: dict[str, Any], category: str) -> dict[str, Any]:
    """Converte o node cru da Shopee no shape consumido pela página PHP."""
    price_min = node.get("priceMin")
    price_max = node.get("priceMax")
    try:
        price_current = float(price_max) if price_max is not None else float(price_min or 0)
    except (TypeError, ValueError):
        price_current = 0.0
    # priceMin costuma ser o preço com desconto, priceMax o original
    price_original = None
    if price_min is not None and price_max is not None:
        try:
            pmin = float(price_min)
            pmax = float(price_max)
            if pmax > pmin:
                price_current = pmin
                price_original = pmax
        except (TypeError, ValueError):
            pass

    return {
        "id": str(node.get("productId") or ""),
        "title": str(node.get("productName") or "").strip(),
        "image": str(node.get("productImage") or "").strip(),
        "category": category,
        "price_current": price_current,
        "price_original": price_original,
        "discount_pct": int(node.get("discountPct") or 0),
        "rating": float(node.get("ratingStar") or 0),
        "sales_count": int(node.get("sales") or 0),
        "url": str(node.get("offerLink") or "").strip(),
        "seller": str(node.get("shopName") or "").strip(),
    }


def dedupe_by_id(products: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Mantém a primeira ocorrência de cada `id` (ordem preservada)."""
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for p in products:
        pid = p.get("id")
        if not pid or pid in seen:
            continue
        seen.add(pid)
        out.append(p)
    return out


def filter_with_discount(products: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return [p for p in products if p.get("discount_pct", 0) > 0]


def pick_achadinho(products: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Escolhe o produto com maior desconto; desempate por mais vendas."""
    if not products:
        return None
    return max(products, key=lambda p: (p.get("discount_pct", 0), p.get("sales_count", 0)))
