"""Persistência atômica do JSON consumido pela página PHP."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo


# Mesmo fuso do `app/bootstrap.php` (default: America/Campo_Grande)
TIMEZONE = "America/Campo_Grande"


def now_iso() -> str:
    """Timestamp ISO-8601 com offset do fuso configurado."""
    return datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds")


def build_payload(achadinho: dict[str, Any] | None, products: list[dict[str, Any]]) -> dict[str, Any]:
    """Monta o JSON no shape esperado pelo `loja_achadinhos/_helpers.php`."""
    counts: dict[str, int] = {}
    for p in products:
        cat = p.get("category", "outros")
        counts[cat] = counts.get(cat, 0) + 1
    return {
        "generated_at": now_iso(),
        "source": "shopee-affiliate-api",
        "category_counts": counts,
        "achadinho_do_dia": achadinho,
        "products": products,
    }


def write(payload: dict[str, Any], output_path: Path) -> None:
    """Escreve o JSON de forma atômica: escreve em .tmp e depois os.replace."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = output_path.with_suffix(output_path.suffix + ".tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp_path, output_path)


def load_existing(output_path: Path) -> dict[str, Any] | None:
    """Lê o JSON atual (ou None se não existir / for inválido)."""
    if not output_path.is_file():
        return None
    try:
        with output_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None
