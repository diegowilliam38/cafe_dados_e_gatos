#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import unicodedata
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

THIS_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = THIS_DIR.parent
sys.path.insert(0, str(PACKAGE_ROOT))

from lib.logger import make_logger
from lib.product_feed import (
    find_preferred_feed,
    iter_feed_rows,
    normalize_product,
    parse_row_columns,
)
from lib.quality import enrich_product_quality
from lib.shopee_client import ShopeeApiError, ShopeeClient
from lib.storage import write

TIMEZONE = "America/Sao_Paulo"
DEFAULT_CONFIG = PACKAGE_ROOT / "config" / "catalog_config.json"
DEFAULT_OUTPUT = PACKAGE_ROOT / "output" / "catalog"
LOGS_DIR = PACKAGE_ROOT / "logs"


def slugify(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-") or "sem-categoria"


def load_catalog_config(path: Path) -> dict:
    if not path.is_file():
        return {
            "site": {"title": "Catalogo Shopee", "base_url": ""},
            "catalog": {
                "mode": "promocoes",
                "limit_per_category": 200,
                "highlights_limit": 24,
                "min_discount_pct": 1,
                "min_price": 1,
                "include_categories": [],
                "exclude_categories": [],
            },
            "deploy": {"remote_dir": "/public_html/data/catalog"},
        }
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def product_sort_key(prod: dict) -> tuple:
    return (
        float(prod.get("score") or 0),
        int(prod.get("discount_pct") or 0),
        int(prod.get("sales_count") or 0),
        float(prod.get("rating") or 0),
    )


def normalize_catalog_mode(value: object) -> str:
    mode = str(value or "promocoes").strip().lower()
    if mode in {"full", "todos", "tudo"}:
        return "full"
    return "promocoes"


def int_from_env_or_config(env_key: str, config_value: object, default: int) -> int:
    raw = os.environ.get(env_key, "").strip()
    value = raw if raw != "" else config_value
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def discount_sort_key(prod: dict) -> tuple:
    return (
        int(prod.get("discount_pct") or 0),
        float(prod.get("score") or 0),
        int(prod.get("sales_count") or 0),
        float(prod.get("rating") or 0),
    )


def sales_sort_key(prod: dict) -> tuple:
    return (
        int(prod.get("sales_count") or 0),
        float(prod.get("score") or 0),
        int(prod.get("discount_pct") or 0),
        float(prod.get("rating") or 0),
    )


def sanitize_product(prod: dict) -> dict | None:
    if not prod.get("id") or not prod.get("title") or not prod.get("image") or not prod.get("url"):
        return None
    price_current = float(prod.get("price_current") or 0)
    if price_current <= 0:
        return None
    clean = {
        "id": str(prod["id"]),
        "title": str(prod["title"]).strip(),
        "image": str(prod["image"]).strip(),
        "url": str(prod["url"]).strip(),
        "price_current": price_current,
        "price_original": prod.get("price_original"),
        "discount_pct": int(prod.get("discount_pct") or 0),
        "rating": float(prod.get("rating") or 0),
        "sales_count": int(prod.get("sales_count") or 0),
        "seller": str(prod.get("seller") or "").strip(),
        "score": float(prod.get("score") or 0),
        "badges": prod.get("badges") or [],
        "category_root": prod.get("category_root"),
        "category_root_label": prod.get("category_root_label"),
        "category_leaf": prod.get("category_leaf"),
        "category_leaf_label": prod.get("category_leaf_label"),
    }
    return clean


def build_offer_fallback(client: ShopeeClient, max_pages: int = 5, page_size: int = 50) -> list[dict]:
    """Fallback de catálogo usando productOfferV2 quando o feed principal não responde.

    Isso não substitui o feed completo, mas evita que o pacote morra em
    ambientes onde listItemFeeds/getItemFeedData estão instáveis.
    """
    parsed: list[dict] = []
    seen_ids: set[str] = set()

    for page in range(1, max_pages + 1):
        nodes = client.fetch_offer_page(page=page, page_size=page_size)
        if not nodes:
            break
        for node in nodes:
            pid = str(node.get("productId") or "").strip()
            title = str(node.get("productName") or "").strip()
            image = str(node.get("productImage") or "").strip()
            url = str(node.get("offerLink") or "").strip()
            if not pid or pid in seen_ids or not title or not image or not url:
                continue

            price_min = node.get("priceMin")
            price_max = node.get("priceMax")
            try:
                price_current = float(price_max) if price_max is not None else float(price_min or 0)
            except (TypeError, ValueError):
                price_current = 0.0

            price_original = None
            if price_min is not None and price_max is not None:
                try:
                    pmin = float(price_min)
                    pmax = float(price_max)
                    if pmax > pmin:
                        price_current = pmin
                        price_original = pmax
                except (TypeError, ValueError):
                    pass

            category_label = str(node.get("categoryName") or "Sem categoria").strip() or "Sem categoria"
            prod = {
                "id": pid,
                "title": title,
                "image": image,
                "url": url,
                "price_current": price_current,
                "price_original": price_original,
                "discount_pct": int(node.get("discountPct") or 0),
                "rating": float(node.get("ratingStar") or 0),
                "sales_count": int(node.get("sales") or 0),
                "seller": str(node.get("shopName") or "").strip(),
                "score": float(node.get("discountPct") or 0) + (int(node.get("sales") or 0) / 1000.0),
                "badges": ["offer-fallback"],
                "category_root": slugify(category_label),
                "category_root_label": category_label,
                "category_leaf": "",
                "category_leaf_label": "",
            }
            parsed.append(prod)
            seen_ids.add(pid)

        if len(nodes) < page_size:
            break

    return parsed


def main() -> int:
    parser = argparse.ArgumentParser(description="Gera um catalogo Shopee generico com todas as categorias.")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--force-full", action="store_true", help="Compatibilidade: FULL ja e preferido.")
    args = parser.parse_args()

    env_path = PACKAGE_ROOT / ".env"
    if env_path.is_file():
        load_dotenv(env_path, override=False)

    config = load_catalog_config(args.config)
    catalog_cfg = config.get("catalog", {})
    catalog_mode = normalize_catalog_mode(
        os.environ.get("CATALOG_MODE", "").strip()
        or catalog_cfg.get("mode", catalog_cfg.get("catalog_mode", "promocoes"))
    )
    limit_per_category = int_from_env_or_config("CATALOG_LIMIT_PER_CATEGORY", catalog_cfg.get("limit_per_category", 200), 200)
    highlights_limit = int_from_env_or_config("CATALOG_HIGHLIGHTS_LIMIT", catalog_cfg.get("highlights_limit", 24), 24)
    min_discount_cfg = int_from_env_or_config("CATALOG_MIN_DISCOUNT_PCT", catalog_cfg.get("min_discount_pct", 1), 1)
    min_discount_pct = 0 if catalog_mode == "full" else min_discount_cfg
    min_price = float(catalog_cfg.get("min_price", 1))
    include_categories = {slugify(x) for x in catalog_cfg.get("include_categories", []) if x}
    exclude_categories = {slugify(x) for x in catalog_cfg.get("exclude_categories", []) if x}

    app_id = os.environ.get("SHOPEE_APP_ID", "").strip()
    app_secret = os.environ.get("SHOPEE_SECRET", "").strip()
    api_url = os.environ.get("SHOPEE_API_URL", "").strip() or "https://open-api.affiliate.shopee.com.br/graphql"
    if not app_id or not app_secret:
        print("[erro] preencha SHOPEE_APP_ID e SHOPEE_SECRET no .env ou nos secrets", file=sys.stderr)
        return 1

    logger, log_path = make_logger(LOGS_DIR)
    logger.add("start", datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"))
    logger.add("config_path", str(args.config))
    logger.add("output_root", str(args.output_root))
    logger.add("timezone", TIMEZONE)
    logger.add("site_title", config.get("site", {}).get("title"))
    logger.add("catalog_mode", catalog_mode)
    logger.add("limit_per_category", limit_per_category)
    logger.add("min_discount_pct", min_discount_pct)

    def emit(msg: str) -> None:
        if args.verbose:
            print(msg, file=sys.stderr)

    client = ShopeeClient(app_id=app_id, app_secret=app_secret, api_url=api_url)
    emit(f"iniciando (log: {log_path})")

    feed = None
    feed_mode_used = None
    try:
        with logger.step("find_full_feed"):
            feed = find_preferred_feed(client, "FULL")
            logger.add("full_feed_id", feed["datafeedId"] if feed else None)
            emit(f"FULL feed: {feed['datafeedId'] if feed else 'nenhum'}")
            if feed:
                feed_mode_used = "FULL"
    except ShopeeApiError as exc:
        logger.add("full_error", str(exc))
        feed = None

    if feed is None:
        try:
            with logger.step("find_delta_feed"):
                feed = find_preferred_feed(client, "DELTA")
                logger.add("delta_feed_id", feed["datafeedId"] if feed else None)
                emit(f"DELTA feed: {feed['datafeedId'] if feed else 'nenhum'}")
                if feed:
                    feed_mode_used = "DELTA"
        except ShopeeApiError as exc:
            logger.add("delta_error", str(exc))
            feed = None

    parsed: list[dict] = []
    skipped_parse = 0
    if feed is not None:
        raw_rows: list[dict] = []
        with logger.step("download_feed"):
            for row in iter_feed_rows(client, feed["datafeedId"]):
                raw_rows.append(row)
        logger.add("rows_downloaded", len(raw_rows))
        emit(f"linhas baixadas: {len(raw_rows)}")

        with logger.step("parse_feed"):
            for row in raw_rows:
                cols = parse_row_columns(row)
                if not cols:
                    skipped_parse += 1
                    continue
                prod = normalize_product(cols)
                if prod is None:
                    skipped_parse += 1
                    continue
                root_label = (prod.get("_category_raw") or "").strip() or "Sem categoria"
                leaf_label = (prod.get("_category2_raw") or "").strip()
                prod["category_root_label"] = root_label
                prod["category_root"] = slugify(root_label)
                prod["category_leaf_label"] = leaf_label
                prod["category_leaf"] = slugify(leaf_label) if leaf_label else ""
                enrich_product_quality(prod)
                parsed.append(prod)
        logger.add("parsed", len(parsed))
        logger.add("skipped_parse", skipped_parse)
    else:
        logger.add("fallback_mode", "productOfferV2")
        emit("feed principal indisponivel; tentando fallback com productOfferV2")
        with logger.step("fallback_offer_pages"):
            parsed = build_offer_fallback(client, max_pages=5, page_size=50)
        logger.add("parsed", len(parsed))
        logger.add("skipped_parse", skipped_parse)
        emit(f"fallback carregou {len(parsed)} produtos via productOfferV2")

    if not parsed:
        logger.save()
        print("[erro] nao foi possivel obter produtos do feed principal nem do fallback productOfferV2.", file=sys.stderr)
        return 1

    deduped: list[dict] = []
    seen_ids: set[str] = set()
    skipped_rules = Counter()
    with logger.step("filter_dedupe"):
        for prod in parsed:
            clean = sanitize_product(prod)
            if clean is None:
                skipped_rules["invalid_shape"] += 1
                continue
            if clean["id"] in seen_ids:
                skipped_rules["duplicate"] += 1
                continue
            if clean["price_current"] < min_price:
                skipped_rules["price_too_low"] += 1
                continue
            if clean["discount_pct"] < min_discount_pct:
                skipped_rules["discount_too_low"] += 1
                continue
            if include_categories and clean["category_root"] not in include_categories:
                skipped_rules["not_in_include"] += 1
                continue
            if clean["category_root"] in exclude_categories:
                skipped_rules["in_exclude"] += 1
                continue
            seen_ids.add(clean["id"])
            deduped.append(clean)
    logger.add("after_dedupe", len(deduped))
    logger.add("skipped_rules", dict(skipped_rules))

    deduped.sort(key=product_sort_key, reverse=True)
    by_category: dict[str, list[dict]] = {}
    labels: dict[str, str] = {}
    leaf_labels: dict[str, Counter] = {}
    for prod in deduped:
        slug = str(prod["category_root"])
        by_category.setdefault(slug, []).append(prod)
        labels.setdefault(slug, str(prod["category_root_label"]))
        leaf = str(prod.get("category_leaf_label") or "").strip()
        if leaf:
            leaf_labels.setdefault(slug, Counter())[leaf] += 1

    output_root = args.output_root
    categories_dir = output_root / "categories"
    highlights_dir = output_root / "highlights"
    categories_dir.mkdir(parents=True, exist_ok=True)
    highlights_dir.mkdir(parents=True, exist_ok=True)

    category_summaries: list[dict] = []
    for slug, products in sorted(by_category.items(), key=lambda item: len(item[1]), reverse=True):
        sorted_products = sorted(products, key=product_sort_key, reverse=True)
        top_products = sorted_products if limit_per_category <= 0 else sorted_products[:limit_per_category]
        best_sellers = sorted(products, key=sales_sort_key, reverse=True)[:highlights_limit]
        top_discounts = sorted(products, key=discount_sort_key, reverse=True)[:highlights_limit]
        leaf_counter = leaf_labels.get(slug, Counter())
        summary = {
            "slug": slug,
            "label": labels.get(slug, slug),
            "count": len(products),
            "top_leaf_categories": [{"label": name, "count": count} for name, count in leaf_counter.most_common(8)],
            "sample_product_ids": [p["id"] for p in top_products[:6]],
        }
        category_summaries.append(summary)
        payload = {
            "generated_at": datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"),
            "category": summary,
            "products": top_products,
            "best_sellers": best_sellers,
            "top_discounts": top_discounts,
        }
        write(payload, categories_dir / f"{slug}.json")

    categories_payload = {
        "generated_at": datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"),
        "site": config.get("site", {}),
        "totals": {
            "categories": len(category_summaries),
            "products": len(deduped),
        },
        "catalog": {
            "mode": catalog_mode,
            "limit_per_category": limit_per_category,
            "min_discount_pct": min_discount_pct,
        },
        "categories": category_summaries,
    }
    write(categories_payload, output_root / "categories.json")

    write(
        {
            "generated_at": datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"),
            "title": "Mais vendidos",
            "products": sorted(deduped, key=sales_sort_key, reverse=True)[:highlights_limit],
        },
        highlights_dir / "best-sellers.json",
    )
    write(
        {
            "generated_at": datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"),
            "title": "Maior desconto",
            "products": sorted(deduped, key=discount_sort_key, reverse=True)[:highlights_limit],
        },
        highlights_dir / "top-discounts.json",
    )
    write(
        {
            "generated_at": datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds"),
            "site": config.get("site", {}),
            "source": "shopee-affiliate-feed" if feed is not None else "shopeeOfferV2-fallback",
            "feed_mode": feed_mode_used or "FALLBACK",
            "feed_id": (feed or {}).get("datafeedId"),
            "products_total": len(deduped),
            "categories_total": len(category_summaries),
            "catalog_mode": catalog_mode,
            "limit_per_category": limit_per_category,
            "min_discount_pct": min_discount_pct,
            "skipped": dict(skipped_rules),
        },
        output_root / "manifest.json",
    )

    logger.add("categories_total", len(category_summaries))
    logger.add("products_total", len(deduped))
    logger.save()
    emit(f"categorias: {len(category_summaries)}; produtos: {len(deduped)}")
    emit(f"gravado em: {output_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
